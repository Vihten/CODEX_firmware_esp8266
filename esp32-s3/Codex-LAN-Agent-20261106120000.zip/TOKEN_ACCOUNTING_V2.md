﻿# Token accounting V2

`weekly_tokens.ps1` maintains `Total` for the current Europe/Kyiv Monday week,
`LifetimeTotal` across available local session logs, and `Revision`. These are
local-log totals, not account billing or an account-wide usage API.
Cached input and reasoning output are subsets; only input + output are counted.

## Lineage and recovery

The scanner reads session_meta.id and session_meta.forked_from_id, scans available
parents first, and deduplicates timestamped cumulative prefixes within a known
family. Metadata-free copies retain the legacy global timestamp/counter identity.
A child's initial inherited baseline is total minus valid last_token_usage only
when explicit fork lineage or an exact earlier cross-file predecessor supports it.
Known incompatible families cannot supply that predecessor. Ordinary cumulative
jumps always use counter differences, including jumps spanning multiple rounds.
Each counter channel resets independently when it decreases.

Without both lineage and an exact retained predecessor, inheritance cannot be
proven. The first observed cumulative value is retained; migration cannot promise
to remove inherited inflation for such incomplete logs. Metadata-free unrelated
sessions with identical timestamp/counters are also inherently ambiguous.
Header timestamps order metadata-free files; absent/malformed headers can prevent
cross-file predecessor inference. Explicit parent graphs take precedence.
Available initial cumulative history is counted even if earlier individual events
are absent. An unavailable baseline before the week cannot be reconstructed.

First V1 migration rebuilds from raw logs, ignoring old inflated totals/checkpoints.
The exact original state is retained as .pre-v2.bak (unique suffix if already
present), and its fields are preserved in Metadata. Corrupt states get a unique
.corrupt.*.bak and a rebuild. Rebuild results depend on retained logs; removed logs
cannot be recovered from an inflated/corrupt checkpoint. Healthy V2 checkpoints
retain already counted lifetime usage across deletion, truncation and week rollover.
File reads allow shared writers/deletion. Incomplete records and after-cutoff
records are replayed; oversized records are bounded and skipped. Only a durably
committed full scan is published. PowerShell 5.1 and 7 date representations work.

## Wire contract

`LFT2,ACCOUNT,CLIENT,WEEK,WEEKLY,LIFETIME,REVISION,COLOR,NAMEHEX`

Nine fields, ASCII, fewer than 200 bytes including the longest 48-byte UTF-8 name
encoded as 96 hex digits. Both UDP and HTTP /agent carry the same committed body.
The receiving controller must support LFT2 and the new 200-byte transport capacity.
There is no LFT1 fallback. Only `LFT2_ACK,DEVICE,CLIENT` is a token acknowledgement;
it does not alter activity, discovery, connection state or color. Existing LFA2
heartbeats remain unchanged. Unsupported controllers must ignore LFT2 packets.
Token reports retry every 15 seconds; failed HTTP bodies have a bounded deadline.

Revision is a committed reporting snapshot ID in [1, 281474976710655], using
max(UTC milliseconds, previous revision + 1) only on first commit or a changed
(Week, Total, LifetimeTotal, ReportIdentity) tuple. PublishedSnapshot stores that tuple. Checkpoints
still persist on unchanged scans, but their revision stays stable: no revision-only
controller NVS writes every 15 seconds. Week rollover changes revision even at zero
usage. Older V2 checkpoints missing PublishedSnapshot get a fresh revision once.
Failed commits restore the previous in-memory revision and published tuple.
ReportIdentity contains the transmitted account, client, color and name hex. Metadata
changes advance revision once; unchanged metadata does not. The sender waits for a
committed matching identity before sending, avoiding stale-revision metadata races.
A lost/corrupt checkpoint cannot preserve an unknown future revision from that
checkpoint; backups retain diagnostic evidence.

## Verification

Run test_weekly_tokens.ps1, test_weekly_token_v2.ps1,
test_weekly_token_http.ps1 and test_weekly_token_backlog.ps1 with Windows PowerShell.
The unit suites also run on PowerShell 7. An optional local token-only audit
fixture checks inherited counters against independent arithmetic; no dialogs
are read and private audit files are not distributed with the release.

No installed agent, firmware, web, release bundle or publication is changed by this
source work. Deploy only after verifying the controller's LFT2 transport/ACK support.
