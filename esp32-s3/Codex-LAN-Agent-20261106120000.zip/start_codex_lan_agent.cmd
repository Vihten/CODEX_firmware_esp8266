@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0codex_lan_agent.ps1" %*
