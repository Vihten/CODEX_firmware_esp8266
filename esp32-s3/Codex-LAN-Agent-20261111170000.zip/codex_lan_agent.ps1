﻿[CmdletBinding()]
param(
    [string]$CollectorHost = '255.255.255.255',
    [ValidateRange(1, 65535)]
    [int]$Port = 4212,
    [ValidateRange(250, 5000)]
    [int]$PollMilliseconds = 1000,
    [string]$SessionsRoot = (Join-Path $env:USERPROFILE '.codex\sessions'),
    [string]$LogPath = '',
    [string]$DirectHost = '255.255.255.255',
    [ValidateRange(1, 65535)]
    [int]$DirectPort = 4210,
    [ValidateRange(1, 65535)]
    [int]$DirectHttpPort = 80,
    [ValidatePattern('^[0-9A-Fa-f]{8}$')]
    [string]$AccountFingerprint = '53197668',
    [ValidateRange(15, 3600)]
    [int]$LimitPollSeconds = 15,
    [switch]$DisableLimitPolling,
    [string]$InstanceName = 'LEDForgeCodexLanAgent',
    [string]$AgentName = '',
    [string]$ColorHex6 = '',
    [string]$MetadataPath = '',
    [string]$ControllerStatePath = '',
    [string]$TokenStatePath = '',
    [string]$UpdateControlPath = ''
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'agent_metadata.ps1')
. (Join-Path $PSScriptRoot 'weekly_tokens.ps1')
if ([string]::IsNullOrWhiteSpace($TokenStatePath)) {
    $TokenStatePath = Join-Path $PSScriptRoot 'weekly-token-state.json'
}
$weeklyTokens = $null
$nextTokenScan = [DateTime]::MinValue
$weeklyTokensReady = $false
$dailyTokens = @()
$dailyTokenIdentity = ''
$dailyTokenIndex = 0
$nextDailyReportAt = [DateTime]::MinValue
$tokenScanner = $null
$claudePoller = $null
$claudeHttpSender = $null
$nextClaudeReportAt = [DateTime]::MinValue
if ([string]::IsNullOrWhiteSpace($MetadataPath)) {
    $MetadataPath = Join-Path $PSScriptRoot 'agent-metadata.json'
}
if (Test-Path -LiteralPath $MetadataPath) {
    $savedMetadata = Get-Content -LiteralPath $MetadataPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $PSBoundParameters.ContainsKey('AgentName')) { $AgentName = $savedMetadata.Name }
    if (-not $PSBoundParameters.ContainsKey('ColorHex6')) { $ColorHex6 = $savedMetadata.ColorHex6 }
}
$metadata = Get-AgentMetadata -Name $AgentName -ColorHex6 $ColorHex6
$script:effectiveColorHex6 = $metadata.ColorHex6
if (-not (Test-Path -LiteralPath $SessionsRoot)) {
    throw "Codex sessions directory was not found: $SessionsRoot"
}

$clientId = "$env:COMPUTERNAME-$env:USERNAME"
$sha256 = [Security.Cryptography.SHA256]::Create()
$clientHashBytes = $sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($clientId))
$clientHash = -join ($clientHashBytes[0..3] | ForEach-Object { $_.ToString('X2') })
$sha256.Dispose()
$udp = [System.Net.Sockets.UdpClient]::new()
$udp.EnableBroadcast = $true
$discoveryUdp = $null
try { $discoveryUdp = [Net.Sockets.UdpClient]::new($DirectPort) }
catch [Net.Sockets.SocketException] { # Another preview may already listen on this port.
}
$offsets = @{}
$remainders = @{}
$sessionActive = @{}
$sessionLastWrite = @{}
$nextSessionDiscovery = [DateTime]::MinValue
$boostUntil = [DateTime]::MinValue
$boostActivity = 0.0
$activity = 0.0
$lastReportedActivity = -1.0
$remainingPercent = -1
$quotaFingerprint = '00000000'
$nextLimitPoll = [DateTime]::MinValue
$script:limitServer = $null
$script:limitServerRequestId = 1
$script:limitServerRetryAt = [DateTime]::MinValue
$directStartedAt = Get-Date
$lastDirectAckAt = [DateTime]::MinValue
$directStatusKnown = $false
$directConnected = $false
$nextDirectHttpAt = [DateTime]::MinValue
$nextWeeklyReportAt = [DateTime]::MinValue
$configuredDirectHost = $DirectHost
$controllerDeviceId = ''
$controllerCacheDirty = $false
$discoveryCandidates = @()
$discoveryIndex = 0
$nextDiscoveryAt = [DateTime]::MinValue
if ([string]::IsNullOrWhiteSpace($ControllerStatePath)) {
    $ControllerStatePath = Join-Path $PSScriptRoot 'controller-endpoint.json'
}
try {
    if (Test-Path -LiteralPath $ControllerStatePath) {
        $savedController = Get-Content -LiteralPath $ControllerStatePath -Raw | ConvertFrom-Json
        $savedIp = $null
        if ($savedController.Seed -eq $configuredDirectHost -and
            $savedController.Account -eq $AccountFingerprint -and
            $savedController.Port -eq $DirectPort -and
            $savedController.HttpPort -eq $DirectHttpPort -and
            $savedController.Device -cmatch '\A[0-9A-Fa-f]{6}\z' -and
            [Net.IPAddress]::TryParse([string]$savedController.Host, [ref]$savedIp) -and
            $savedIp.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork) {
            $DirectHost = $savedController.Host
            $controllerDeviceId = $savedController.Device.ToUpperInvariant()
        }
    }
}
catch { # A missing or damaged optional cache must not stop telemetry.
}
$confirmedDirectHost = $DirectHost

function Write-AgentStatus([string]$Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Write-Host $line
    if (-not [string]::IsNullOrWhiteSpace($LogPath)) {
        try {
            Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
        }
        catch {
            # Logging is optional and must never stop activity reporting.
        }
    }
}

function Find-CodexExecutable {
    $command = Get-Command codex -ErrorAction SilentlyContinue
    if ($null -ne $command -and (Test-Path -LiteralPath $command.Source)) {
        return $command.Source
    }

    $desktopRoot = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
    if (Test-Path -LiteralPath $desktopRoot) {
        $desktop = Get-ChildItem -LiteralPath $desktopRoot -Recurse -Filter 'codex.exe' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 1
        if ($null -ne $desktop) { return $desktop.FullName }
    }

    $extensionsRoot = Join-Path $env:USERPROFILE '.vscode\extensions'
    if (Test-Path -LiteralPath $extensionsRoot) {
        $extension = Get-ChildItem -LiteralPath $extensionsRoot -Directory -Filter 'openai.chatgpt-*' -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending |
            Select-Object -First 1
        if ($null -ne $extension) {
            $candidate = Join-Path $extension.FullName 'bin\windows-x86_64\codex.exe'
            if (Test-Path -LiteralPath $candidate) { return $candidate }
        }
    }
    return $null
}

function Send-AppServerLine(
    [Diagnostics.Process]$Process,
    [hashtable]$Message
) {
    $Process.StandardInput.WriteLine(($Message | ConvertTo-Json -Compress -Depth 10))
    $Process.StandardInput.Flush()
}

function Read-AppServerResponse(
    [Diagnostics.Process]$Process,
    [int]$Id,
    [int]$TimeoutSeconds = 3
) {
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $pendingRead = $null
    while ([DateTime]::UtcNow -lt $deadline) {
        if ($null -eq $pendingRead) {
            $pendingRead = $Process.StandardOutput.ReadLineAsync()
        }
        if (-not $pendingRead.Wait(200)) { continue }
        $line = $pendingRead.Result
        $pendingRead = $null
        if ($null -eq $line) { return $null }
        try {
            $message = $line | ConvertFrom-Json
            if ($message.id -eq $Id) { return $message }
        }
        catch {
            # Ignore diagnostics accidentally written to the protocol stream.
        }
    }
    return $null
}

function Stop-LimitAppServer {
    $process = $script:limitServer
    $script:limitServer = $null
    $script:limitServerRequestId = 1
    if ($null -eq $process) { return }
    try {
        if (-not $process.HasExited) {
            $process.Kill()
            [void]$process.WaitForExit(1000)
        }
    }
    catch { # Already exited, or failed before Start completed.
    }
    finally { $process.Dispose() }
}

function Get-AccountFingerprint([string]$Email) {
    if ([string]::IsNullOrWhiteSpace($Email)) { return '00000000' }
    [uint64]$hash = 2166136261
    foreach ($unit in $Email.Trim().ToLowerInvariant().ToCharArray()) {
        $hash = (($hash -bxor [uint64][char]$unit) * [uint64]16777619) -band [uint64]4294967295
    }
    return $hash.ToString('X8')
}

function Read-QuotaAccountFingerprint([Diagnostics.Process]$Process) {
    $script:limitServerRequestId++
    $requestId = $script:limitServerRequestId
    Send-AppServerLine $Process @{
        method = 'account/read'; id = $requestId; params = @{ refreshToken = $false }
    }
    $response = Read-AppServerResponse $Process $requestId
    if ($null -eq $response -or $null -ne $response.error) { throw 'Account verification failed.' }
    return Get-AccountFingerprint $response.result.account.email
}

function Get-RemainingPercent {
    # The worker calls this serially. Keep one initialized stdio connection;
    # never retain a timed-out read or reuse a stream after protocol failure.
    $script:remainingPercent = -1
    $script:quotaFingerprint = '00000000'
    if ([DateTime]::UtcNow -lt $script:limitServerRetryAt) { return -1 }
    try {
        if ($null -eq $script:limitServer) {
            $executable = Find-CodexExecutable
            if ([string]::IsNullOrWhiteSpace($executable)) { throw 'Codex executable unavailable.' }
            $processInfo = [Diagnostics.ProcessStartInfo]::new()
            $processInfo.FileName = $executable
            $processInfo.Arguments = 'app-server --stdio --disable shell_tool --disable unified_exec'
            $processInfo.UseShellExecute = $false
            $processInfo.CreateNoWindow = $true
            $processInfo.RedirectStandardInput = $true
            $processInfo.RedirectStandardOutput = $true
            $processInfo.RedirectStandardError = $true
            $script:limitServer = [Diagnostics.Process]::new()
            $script:limitServer.StartInfo = $processInfo
            if (-not $script:limitServer.Start()) { throw 'App-server did not start.' }
            # Drain and discard diagnostics as they arrive, without accumulating
            # the lifetime stderr transcript in a ReadToEndAsync task.
            $script:limitServer.BeginErrorReadLine()
            Send-AppServerLine $script:limitServer @{
                method = 'initialize'
                id = 1
                params = @{
                    clientInfo = @{
                        name = 'led_forge_lan_agent'
                        title = 'LED Forge LAN Agent'
                        version = '1.0.0'
                    }
                    capabilities = @{ experimentalApi = $true }
                }
            }
            $initialized = Read-AppServerResponse $script:limitServer 1
            if ($null -eq $initialized -or $null -ne $initialized.error) { throw 'App-server initialization failed.' }
            Send-AppServerLine $script:limitServer @{ method = 'initialized'; params = @{} }
        }
        $process = $script:limitServer
        if ($process.HasExited) { throw 'App-server exited.' }
        # Verify the identity reported by this server, on both sides of the
        # quota request. This cannot force an older server to reload cached auth.
        $beforeFingerprint = Read-QuotaAccountFingerprint $process
        if ($beforeFingerprint -ne $AccountFingerprint) { return -1 }
        $script:limitServerRequestId++
        $requestId = $script:limitServerRequestId
        Send-AppServerLine $process @{
            method = 'account/rateLimits/read'
            id = $requestId
            params = @{}
        }
        $response = Read-AppServerResponse $process $requestId
        if ($null -eq $response -or $null -ne $response.error) { throw 'App-server limits request failed.' }

        $afterFingerprint = Read-QuotaAccountFingerprint $process
        if ($afterFingerprint -ne $AccountFingerprint) { return -1 }

        $limits = @()
        $byId = $response.result.rateLimitsByLimitId
        if ($null -ne $byId) {
            $limits = @($byId.PSObject.Properties | ForEach-Object { $_.Value })
        }
        elseif ($null -ne $response.result.rateLimits) {
            $limits = @($response.result.rateLimits)
        }
        $maximumUsed = $null
        foreach ($limit in $limits) {
            foreach ($window in @($limit.primary, $limit.secondary)) {
                if ($null -eq $window -or $null -eq $window.usedPercent) { continue }
                $used = [double]$window.usedPercent
                if ($null -eq $maximumUsed -or $used -gt $maximumUsed) {
                    $maximumUsed = $used
                }
            }
        }
        if ($null -eq $maximumUsed) { return -1 }
        $remaining = [Math]::Max(0.0, [Math]::Min(100.0, 100.0 - $maximumUsed))
        $script:quotaFingerprint = $AccountFingerprint.ToUpperInvariant()
        return [Math]::Round($remaining, 2)
    }
    catch {
        Stop-LimitAppServer
        $script:limitServerRetryAt = [DateTime]::UtcNow.AddSeconds(60)
        return -1
    }
}

function Update-AccountRemaining([double]$LatestRemaining) {
    # Shared account usage cannot identify which local client did the work.
    $script:remainingPercent = [int][Math]::Round($LatestRemaining)
}

function Get-RecentSessionFiles {
    $result = @{}
    $now = Get-Date
    foreach ($day in @((Get-Date), (Get-Date).AddDays(-1))) {
        $directory = Join-Path $SessionsRoot $day.ToString('yyyy')
        $directory = Join-Path $directory $day.ToString('MM')
        $directory = Join-Path $directory $day.ToString('dd')
        if (-not (Test-Path -LiteralPath $directory)) { continue }
        foreach ($file in Get-ChildItem -LiteralPath $directory -Filter '*.jsonl' -File -ErrorAction SilentlyContinue) {
            if ($file.LastWriteTime -gt $now.AddMinutes(-10) -or $offsets.ContainsKey($file.FullName)) {
                $result[$file.FullName] = $file
            }
        }
    }
    foreach ($path in @($offsets.Keys)) {
        if ($result.ContainsKey($path)) { continue }
        $file = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
        if ($null -ne $file) { $result[$path] = $file }
    }
    if ($now -ge $nextSessionDiscovery) {
        $script:nextSessionDiscovery = $now.AddSeconds(15)
        foreach ($file in Get-ChildItem -LiteralPath $SessionsRoot -Filter '*.jsonl' -File -Recurse -ErrorAction SilentlyContinue) {
            if ($file.LastWriteTime -gt $now.AddMinutes(-10)) {
                $result[$file.FullName] = $file
            }
        }
    }
    return $result.Values
}

function Apply-SessionLine(
    [string]$Path,
    [string]$Line,
    [bool]$AllowTokenBoost
) {
    if ($Line -notlike '*"type":"task_started"*' -and
        $Line -notlike '*"type":"task_complete"*' -and
        $Line -notlike '*"type":"turn_aborted"*' -and
        $Line -notlike '*"type":"token_count"*') {
        return
    }
    try {
        $event = $Line | ConvertFrom-Json
        if ($event.type -ne 'event_msg') { return }
        $eventType = [string]$event.payload.type
        switch ($eventType) {
            'task_started' {
                $sessionActive[$Path] = $true
            }
            'task_complete' {
                $sessionActive[$Path] = $false
            }
            'turn_aborted' {
                $sessionActive[$Path] = $false
            }
            'token_count' {
                if (-not $AllowTokenBoost) { return }
                $usage = $event.payload.info.last_token_usage
                $workTokens = [double]$usage.output_tokens + [double]$usage.reasoning_output_tokens
                if ($workTokens -le 0) { return }
                $level = if ($workTokens -ge 2000) {
                    0.90
                }
                elseif ($workTokens -ge 1000) {
                    0.70
                }
                elseif ($workTokens -ge 250) {
                    0.50
                }
                elseif ($workTokens -ge 50) {
                    0.30
                }
                else {
                    0.10
                }
                $script:boostActivity = [Math]::Max($script:boostActivity, $level)
                $script:boostUntil = (Get-Date).AddSeconds(8)
            }
        }
    }
    catch {
        # A concurrently written final line will be retried after the next append.
    }
}

function Initialize-Session([System.IO.FileInfo]$File) {
    $path = $File.FullName
    $offsets[$path] = $File.Length
    $remainders[$path] = ''
    $sessionActive[$path] = $false
    $sessionLastWrite[$path] = $File.LastWriteTime

    $stream = [System.IO.File]::Open(
        $path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
    )
    try {
        $tailBytes = 4MB
        $start = [Math]::Max(0, $stream.Length - $tailBytes)
        [void]$stream.Seek($start, [System.IO.SeekOrigin]::Begin)
        $reader = [System.IO.StreamReader]::new($stream)
        try {
            if ($start -gt 0) { [void]$reader.ReadLine() }
            while (-not $reader.EndOfStream) {
                Apply-SessionLine $path $reader.ReadLine() $false
            }
        }
        finally {
            $reader.Dispose()
        }
    }
    finally {
        $stream.Dispose()
    }
}

function Read-NewSessionContent([System.IO.FileInfo]$File) {
    $path = $File.FullName
    $length = $File.Length
    if (-not $offsets.ContainsKey($path)) {
        Initialize-Session $File
        return
    }
    $offset = [long]$offsets[$path]
    if ($length -lt $offset) {
        $offset = 0
        $remainders[$path] = ''
        $sessionActive[$path] = $false
    }
    if ($length -eq $offset) { return }

    $stream = [System.IO.File]::Open(
        $path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
    )
    try {
        [void]$stream.Seek($offset, [System.IO.SeekOrigin]::Begin)
        $reader = [System.IO.StreamReader]::new($stream)
        try {
            $text = $reader.ReadToEnd()
            $offsets[$path] = $stream.Position
        }
        finally {
            $reader.Dispose()
        }
    }
    finally {
        $stream.Dispose()
    }

    if ([string]::IsNullOrEmpty($text)) { return }
    $sessionLastWrite[$path] = $File.LastWriteTime
    $combined = [string]$remainders[$path] + $text
    $lines = $combined -split "`n"
    $remainders[$path] = $lines[-1]
    for ($index = 0; $index -lt $lines.Count - 1; $index++) {
        Apply-SessionLine $path $lines[$index].TrimEnd("`r") $true
    }
}

function Get-CurrentActivity {
    $now = Get-Date
    $activeCount = 0
    foreach ($path in @($sessionActive.Keys)) {
        $lastWrite = $sessionLastWrite[$path]
        if ($sessionActive[$path] -and
            $null -ne $lastWrite -and
            $now - $lastWrite -lt [TimeSpan]::FromHours(2)) {
            $activeCount++
        }
    }
    $taskActivity = if ($activeCount -gt 0) {
        (2 * [Math]::Min($activeCount, 5) - 1) / 10.0
    } else { 0.0 }
    if ($now -ge $boostUntil) {
        $script:boostActivity = 0.0
    }
    return [Math]::Max($taskActivity, $script:boostActivity)
}


# Claude credentials remain inside this independent worker and never enter telemetry.
function ConvertTo-ClaudeQuota($Usage, [DateTimeOffset]$Now = [DateTimeOffset]::UtcNow) {
    $window = $Usage.five_hour
    if ($null -eq $window -or $null -eq $window.utilization -or
        $window.utilization -is [string] -or $window.utilization -is [bool]) { return $null }
    $used = 0.0
    if (-not [double]::TryParse([string]$window.utilization,
        [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$used) -or
        [double]::IsNaN($used) -or [double]::IsInfinity($used) -or $used -lt 0 -or $used -gt 100) { return $null }
    $reset = [DateTimeOffset]::MinValue
    if ($window.resets_at -is [DateTimeOffset]) { $reset = $window.resets_at }
    elseif ($window.resets_at -is [DateTime] -and $window.resets_at.Kind -ne [DateTimeKind]::Unspecified) {
        $reset = [DateTimeOffset]$window.resets_at
    }
    elseif ([string]$window.resets_at -notmatch '(Z|[+-]\d{2}:\d{2})$' -or
        -not [DateTimeOffset]::TryParse([string]$window.resets_at,
            [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$reset)) { return $null }
    if ($reset -le $Now -or $reset -gt $Now.AddHours(5).AddMinutes(1)) { return $null }
    [pscustomobject]@{ Remaining = [int][Math]::Floor(100 - $used); ResetAt = $reset }
}

function Read-ClaudeQuota {
    $ErrorActionPreference = 'Stop'
    try {
        $local = Get-Content -LiteralPath (Join-Path $env:USERPROFILE '.claude.json') -Raw | ConvertFrom-Json
        $oauth = (Get-Content -LiteralPath (Join-Path $env:USERPROFILE '.claude/.credentials.json') -Raw | ConvertFrom-Json).claudeAiOauth
        $identity = $local.oauthAccount
        $now = [DateTimeOffset]::UtcNow
        $expires = 0.0
        if ($null -eq $oauth.expiresAt -or -not [double]::TryParse([string]$oauth.expiresAt,
            [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$expires) -or
            [double]::IsNaN($expires) -or [double]::IsInfinity($expires) -or
            $expires -le $now.ToUnixTimeMilliseconds()) { return }
        if ([string]$identity.emailAddress -cne 'marketing@tiras.ua' -or
            [string]::IsNullOrWhiteSpace([string]$identity.accountUuid) -or
            [string]::IsNullOrWhiteSpace([string]$identity.organizationUuid) -or
            ($null -ne $oauth.PSObject.Properties['organizationUuid'] -and
                $identity.organizationUuid -cne $oauth.organizationUuid) -or
            [string]::IsNullOrWhiteSpace([string]$oauth.accessToken)) { return }
        $headers = @{ Authorization = "Bearer $($oauth.accessToken)"; 'anthropic-beta' = 'oauth-2025-04-20' }
        $profile = Invoke-RestMethod -Uri 'https://api.anthropic.com/api/oauth/profile' -Headers $headers -TimeoutSec 4 -MaximumRedirection 0
        if ([string]$profile.account.email -cne 'marketing@tiras.ua' -or
            $profile.account.uuid -cne $identity.accountUuid -or
            $profile.organization.uuid -cne $identity.organizationUuid) { return }
        $usage = Invoke-RestMethod -Uri 'https://api.anthropic.com/api/oauth/usage' -Headers $headers -TimeoutSec 4 -MaximumRedirection 0
        $quota = ConvertTo-ClaudeQuota $usage
        if ($null -ne $quota) {
            [pscustomobject]@{ Remaining = $quota.Remaining; ResetAt = $quota.ResetAt
                FetchedAt = [DateTimeOffset]::UtcNow; Fingerprint = (Get-AccountFingerprint 'marketing@tiras.ua') }
        }
    }
    catch { # Return only a sanitized rate-limit delay, never the response or credentials.
        if ($null -ne $_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 429) {
            $retry = [string]$_.Exception.Response.Headers['Retry-After']
            $seconds = 0.0
            $date = [DateTimeOffset]::MinValue
            if ([double]::TryParse($retry, [Globalization.NumberStyles]::Float,
                [Globalization.CultureInfo]::InvariantCulture, [ref]$seconds)) {
                if ([double]::IsNaN($seconds) -or [double]::IsInfinity($seconds)) { $seconds = 0 }
            }
            elseif ([DateTimeOffset]::TryParse($retry, [ref]$date)) {
                $seconds = ($date - [DateTimeOffset]::UtcNow).TotalSeconds
            }
            [pscustomobject]@{ RetrySeconds = [Math]::Max(60, [Math]::Min(86400, $seconds)) }
        }
    }
    finally { $headers = $null; $oauth = $null; $profile = $null; $local = $null }
}

function New-ClaudeQuotaPoller {
    @{ Worker = $null; Pending = $null; Stopping = $null; Started = [DateTimeOffset]::MinValue
        NextPoll = [DateTimeOffset]::MinValue; Failures = 0; Quota = $null
        Configured = (Test-Path -LiteralPath (Join-Path $env:USERPROFILE '.claude.json')) }
}

function Stop-ClaudeQuotaWorker($State) {
    if ($null -eq $State.Worker) { return }
    try {
        if ($null -ne $State.Stopping) { $State.Worker.EndStop($State.Stopping) }
        elseif ($null -ne $State.Pending -and -not $State.Pending.IsCompleted) { $State.Worker.Stop() }
        if ($null -ne $State.Pending) { try { [void]$State.Worker.EndInvoke($State.Pending) } catch { } }
    }
    finally {
        $State.Worker.Dispose(); $State.Worker = $null; $State.Pending = $null; $State.Stopping = $null
    }
}

function Update-ClaudeQuotaPoller($State, [DateTimeOffset]$Now = [DateTimeOffset]::UtcNow) {
    if ($null -ne $State.Pending) {
        if ($null -ne $State.Stopping) {
            if ($State.Stopping.IsCompleted) { Stop-ClaudeQuotaWorker $State }
        }
        elseif ($State.Pending.IsCompleted) {
            $result = $null
            try { $result = @($State.Worker.EndInvoke($State.Pending)) | Select-Object -Last 1 } catch { }
            $State.Pending = $null
            Stop-ClaudeQuotaWorker $State
            if ($null -ne $result -and $result.Fingerprint -ceq (Get-AccountFingerprint 'marketing@tiras.ua') -and
                $result.Remaining -ge 0 -and $result.Remaining -le 100 -and
                $result.FetchedAt -le $Now -and ($Now - $result.FetchedAt).TotalSeconds -lt 90 -and $result.ResetAt -gt $Now) {
                $State.Quota = $result; $State.Configured = $true; $State.Failures = 0
            }
            else { $State.Failures = [Math]::Min(4, $State.Failures + 1) }
            $delay = [Math]::Min(900, 60 * [Math]::Pow(2, $State.Failures))
            if ($null -ne $result -and $result.RetrySeconds -gt $delay) { $delay = $result.RetrySeconds }
            $State.NextPoll = $Now.AddSeconds($delay)
        }
        elseif (($Now - $State.Started).TotalSeconds -ge 10) {
            # BeginStop avoids blocking the heartbeat on cancellation. Do not replace until disposed.
            $State.Stopping = $State.Worker.BeginStop($null, $null)
            $State.Failures = [Math]::Min(4, $State.Failures + 1)
            $State.NextPoll = $Now.AddSeconds([Math]::Min(900, 60 * [Math]::Pow(2, $State.Failures)))
        }
    }
    if ($null -ne $State.Quota -and (($Now - $State.Quota.FetchedAt).TotalSeconds -ge 90 -or
        $State.Quota.FetchedAt -gt $Now -or $State.Quota.ResetAt -le $Now)) { $State.Quota = $null }
    if ($null -eq $State.Worker -and $Now -ge $State.NextPoll) {
        $State.Worker = [PowerShell]::Create()
        try {
            foreach ($name in @('Get-AccountFingerprint', 'ConvertTo-ClaudeQuota', 'Read-ClaudeQuota')) {
                [void]$State.Worker.AddScript("function $name { $( (Get-Item "function:$name").Definition ) }")
            }
            [void]$State.Worker.AddScript('Read-ClaudeQuota')
            $State.Started = $Now
            $State.Pending = $State.Worker.BeginInvoke()
        }
        catch {
            Stop-ClaudeQuotaWorker $State
            $State.NextPoll = $Now.AddSeconds(120)
        }
    }
}

function New-ClaudeQuotaPacket($State, [string]$Account, [string]$Client,
    [DateTimeOffset]$Now = [DateTimeOffset]::UtcNow) {
    if ($Account -cnotmatch '\A[0-9A-Fa-f]{8}\z' -or $Client -cnotmatch '\A[0-9A-Fa-f]{8}\z') { throw 'Invalid Claude packet identity.' }
    $remaining = -1; $fingerprint = '00000000'; $validForMs = 0
    $quota = $State.Quota
    if ($null -ne $quota -and $quota.Fingerprint -ceq (Get-AccountFingerprint 'marketing@tiras.ua') -and
        $quota.Remaining -ge 0 -and $quota.Remaining -le 100 -and $quota.FetchedAt -le $Now -and
        ($Now - $quota.FetchedAt).TotalSeconds -lt 90 -and $quota.ResetAt -gt $Now) {
        $remaining = $quota.Remaining; $fingerprint = $quota.Fingerprint
        $validForMs = [int][Math]::Floor([Math]::Min(90000 - ($Now - $quota.FetchedAt).TotalMilliseconds,
            ($quota.ResetAt - $Now).TotalMilliseconds))
        if ($validForMs -le 0) { $remaining = -1; $fingerprint = '00000000'; $validForMs = 0 }
    }
    "LFC1,$Account,$Client,$remaining,$fingerprint,$validForMs"
}

function Update-ClaudeHttpSender($State) {
    if ($null -eq $State -or $null -eq $State.Pending) { return }
    if ($null -ne $State.Stopping) {
        if ($State.Stopping.IsCompleted) { Stop-ClaudeQuotaWorker $State }
    }
    elseif ($State.Pending.IsCompleted) { Stop-ClaudeQuotaWorker $State }
    elseif (([DateTimeOffset]::UtcNow - $State.Started).TotalMilliseconds -ge 750) {
        $State.Stopping = $State.Worker.BeginStop($null, $null)
    }
}

function Start-ClaudeHttpSend($State, [byte[]]$Bytes, [string]$Address, [int]$HttpPort) {
    Update-ClaudeHttpSender $State
    if ($null -eq $State -or $null -ne $State.Worker) { return }
    $State.Worker = [PowerShell]::Create()
    try {
        [void]$State.Worker.AddScript("function Send-DirectHttpPacket { $((Get-Item 'function:Send-DirectHttpPacket').Definition) }")
        [void]$State.Worker.AddScript({
            param($Bytes, $Address, $HttpPort)
            $DirectHost = $Address; $DirectHttpPort = $HttpPort
            [void](Send-DirectHttpPacket $Bytes)
        }).AddArgument($Bytes).AddArgument($Address).AddArgument($HttpPort)
        $State.Started = [DateTimeOffset]::UtcNow
        $State.Pending = $State.Worker.BeginInvoke()
    }
    catch { Stop-ClaudeQuotaWorker $State }
}

function Send-Heartbeat {
    $message = @{
        version = 1
        client = $clientId
        activity = [Math]::Round($script:activity, 2)
        # Legacy bridge has no quota identity; only LFA3 may carry quota.
        remaining = -1
        name = $metadata.Name
        color = $script:effectiveColorHex6
    } | ConvertTo-Json -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($message)
    try { [void]$udp.Send($bytes, $bytes.Length, $CollectorHost, $Port) }
    catch [Net.Sockets.SocketException] { }

    $activityPercent = [int][Math]::Round($script:activity * 100)
    $directMessage = "LFA3,$AccountFingerprint,$clientHash,$activityPercent,$script:remainingPercent,$script:quotaFingerprint,$($metadata.ColorHex6),$($metadata.NameUtf8Hex)"
    $directBytes = [Text.Encoding]::ASCII.GetBytes($directMessage)
    try { [void]$udp.Send($directBytes, $directBytes.Length, $DirectHost, $DirectPort) }
    catch [Net.Sockets.SocketException] { }

    $now = Get-Date
    if ($now -ge $script:nextDirectHttpAt) {
        $script:nextDirectHttpAt = $now.AddSeconds(2)
        $ack = Send-DirectHttpPacket $directBytes
        if ($null -ne $ack) {
            Confirm-DirectController $ack "http://${DirectHost}:$DirectHttpPort" $DirectHost
        }
    }
    if ($null -ne $script:claudePoller -and $script:claudePoller.Configured -and
        $now -ge $script:nextClaudeReportAt -and -not $DisableLimitPolling) {
        $script:nextClaudeReportAt = $now.AddSeconds(5)
        $claudeBytes = [Text.Encoding]::ASCII.GetBytes((New-ClaudeQuotaPacket $script:claudePoller $AccountFingerprint $clientHash))
        try { [void]$udp.Send($claudeBytes, $claudeBytes.Length, $DirectHost, $DirectPort) }
        catch [Net.Sockets.SocketException] { }
        Start-ClaudeHttpSend $script:claudeHttpSender $claudeBytes $DirectHost $DirectHttpPort
    }
    $sentWeekly = $false
    $reportIdentity = ("$AccountFingerprint,$clientHash,$($metadata.ColorHex6),$($metadata.NameUtf8Hex)").ToUpperInvariant()
    if ($script:weeklyTokens.ReportIdentity -ceq $reportIdentity -and $now -ge $script:nextWeeklyReportAt -and $script:weeklyTokensReady -and
        $script:weeklyTokens.Week -eq (Get-TokenWeek ([DateTimeOffset]::UtcNow))) {
        $sentWeekly = $true
        $script:nextWeeklyReportAt = $now.AddSeconds(15)
        $tokenMessage = New-WeeklyTokenPacket $script:weeklyTokens $AccountFingerprint $clientHash $metadata.ColorHex6 $metadata.NameUtf8Hex
        $tokenBytes = [Text.Encoding]::ASCII.GetBytes($tokenMessage)
        try { [void]$udp.Send($tokenBytes, $tokenBytes.Length, $DirectHost, $DirectPort) }
        catch [Net.Sockets.SocketException] { }
        # Retry the committed snapshot next interval even when UDP has no ACK or HTTP fails.
        $ack = Send-DirectHttpPacket $tokenBytes
        if ($null -ne $ack) { [void](Test-WeeklyTokenAcknowledgement $ack) }
    }
    # One dated absolute snapshot per interval, never a 366-request burst.
    # LFD1_RAM_ACK confirms volatile RAM acceptance, never durable storage.
    # Replay the bounded backlog cyclically even after ACK/loss/controller reboot.
    if (-not $sentWeekly -and $script:dailyTokenIdentity -ceq $reportIdentity -and
        $script:dailyTokens.Count -gt 0 -and $now -ge $script:nextDailyReportAt) {
        $script:nextDailyReportAt = $now.AddSeconds(2)
        if ($script:dailyTokenIndex -ge $script:dailyTokens.Count) { $script:dailyTokenIndex = 0 }
        $day = $script:dailyTokens[$script:dailyTokenIndex]
        $script:dailyTokenIndex = ($script:dailyTokenIndex + 1) % $script:dailyTokens.Count
        $dayMessage = New-DailyTokenPacket $day $AccountFingerprint $clientHash $metadata.ColorHex6 $metadata.NameUtf8Hex
        $dayBytes = [Text.Encoding]::ASCII.GetBytes($dayMessage)
        try { [void]$udp.Send($dayBytes, $dayBytes.Length, $DirectHost, $DirectPort) }
        catch [Net.Sockets.SocketException] { }
        $ack = Send-DirectHttpPacket $dayBytes
        if ($null -ne $ack) { [void](Test-DailyTokenAcknowledgement $ack $day) }
    }
}

function Send-DirectHttpPacket([byte[]]$Bytes) {
    $request = [Net.HttpWebRequest]::Create("http://${DirectHost}:$DirectHttpPort/agent")
    $request.Method = 'POST'
    $request.ContentType = 'text/plain'
    $request.Timeout = 750
    $request.ReadWriteTimeout = 750
    $request.Proxy = $null
    $request.AllowAutoRedirect = $false
    $request.KeepAlive = $false
    $request.ServicePoint.Expect100Continue = $false
    $request.ContentLength = $Bytes.Length
    $deadline = [DateTime]::UtcNow.AddMilliseconds(750)
    try {
        $pending = $request.BeginGetRequestStream($null, $null)
        try {
            if (-not $pending.AsyncWaitHandle.WaitOne([Math]::Max(0, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds))) { return }
            $stream = $request.EndGetRequestStream($pending)
        }
        finally { $pending.AsyncWaitHandle.Close() }
        try { $stream.Write($Bytes, 0, $Bytes.Length) }
        finally { $stream.Dispose() }
        $pending = $request.BeginGetResponse($null, $null)
        try {
            if (-not $pending.AsyncWaitHandle.WaitOne([Math]::Max(0, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds))) { return }
            $response = $request.EndGetResponse($pending)
        }
        finally { $pending.AsyncWaitHandle.Close() }
        try {
            $stream = $response.GetResponseStream()
            $buffer = [byte[]]::new(200)
            $count = 0
            while ($count -lt $buffer.Length) {
                $remaining = [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds
                if ($remaining -le 0) { return }
                $stream.ReadTimeout = $remaining
                $read = $stream.Read($buffer, $count, $buffer.Length - $count)
                if ($read -eq 0) { return [Text.Encoding]::ASCII.GetString($buffer, 0, $count) }
                $count += $read
            }
            # ACKs are short. Reject oversized or endlessly streaming responses.
        }
        finally { $response.Dispose() }
    }
    catch [Net.WebException] { }
    catch [IO.IOException] { }
    finally { $request.Abort() }
}

function Test-DailyTokenAcknowledgement([string]$Response, $Day) {
    $parts = $Response.Trim() -split ','
    return ($parts.Count -eq 5 -and $parts[0] -ceq 'LFD1_RAM_ACK' -and
        $parts[1] -cmatch '\A[0-9A-Fa-f]{6}\z' -and $parts[2] -eq $clientHash -and
        ([string]::IsNullOrEmpty($controllerDeviceId) -or $parts[1] -eq $controllerDeviceId) -and
        $parts[3] -ceq [string]$Day.Day -and $parts[4] -ceq [string]$Day.Revision)
}

function Test-WeeklyTokenAcknowledgement([string]$Response) {
    $parts = $Response.Trim() -split ','
    return ($parts.Count -eq 3 -and $parts[0] -ceq 'LFT2_ACK' -and
        $parts[1] -cmatch '\A[0-9A-Fa-f]{6}\z' -and $parts[2] -eq $clientHash -and
        ([string]::IsNullOrEmpty($controllerDeviceId) -or $parts[1] -eq $controllerDeviceId))
}

function Confirm-DirectController([string]$Response, [string]$Endpoint, [string]$HostAddress = '') {
    $parts = $Response.Trim() -split ','
    if (($parts.Count -ne 3 -and $parts.Count -ne 4) -or
        $parts[0] -ne 'LFA2_ACK' -or
        $parts[1] -cnotmatch '\A[0-9A-Fa-f]{6}\z' -or
        (-not [string]::IsNullOrEmpty($controllerDeviceId) -and $parts[1] -ne $controllerDeviceId) -or
        $parts[2] -ne $clientHash) {
        return
    }
    if ($parts.Count -eq 4) {
        if ($parts[3] -cnotmatch '\A[0-9A-Fa-f]{6}\z') { return }
        $script:effectiveColorHex6 = $parts[3].ToUpperInvariant()
    }
    $script:lastDirectAckAt = Get-Date
    $changed = $controllerDeviceId -eq '' -or ($HostAddress -ne '' -and $HostAddress -ne $confirmedDirectHost)
    $script:controllerDeviceId = $parts[1].ToUpperInvariant()
    if ($HostAddress -ne '') { $script:DirectHost = $HostAddress }
    $script:confirmedDirectHost = $DirectHost
    if ($changed) { $script:controllerCacheDirty = $true }
    if ($controllerCacheDirty) {
        try {
            @{ Seed = $configuredDirectHost; Account = $AccountFingerprint; Port = $DirectPort;
                HttpPort = $DirectHttpPort; Host = $DirectHost; Device = $controllerDeviceId } |
                ConvertTo-Json | Set-Content -LiteralPath $ControllerStatePath -Encoding UTF8
            $script:controllerCacheDirty = $false
        }
        catch { # Connectivity must survive an unwritable cache.
        }
    }
    if (-not $script:directConnected) {
        Write-AgentStatus "direct controller connected: $($parts[1]) at $Endpoint"
    }
    $script:directConnected = $true
    $script:directStatusKnown = $true
}

function Read-DirectAcknowledgements {
    while ($udp.Available -gt 0) {
        $remoteEndpoint = [Net.IPEndPoint]::new([Net.IPAddress]::Any, 0)
        try {
            $responseBytes = $udp.Receive([ref]$remoteEndpoint)
        }
        catch [Net.Sockets.SocketException] {
            # Routed networks may reject UDP while HTTP to the same controller works.
            break
        }
        $response = [Text.Encoding]::ASCII.GetString($responseBytes)
        if ($remoteEndpoint.Port -ne $DirectPort -or
            ($remoteEndpoint.Address.ToString() -ne $DirectHost -and $DirectHost -ne '255.255.255.255')) { continue }
        if ($response -clike 'LFD1_RAM_ACK,*') { continue } # never adopt controller/color from calendar ACKs
        if ($response -clike 'LFT2_ACK,*') {
            [void](Test-WeeklyTokenAcknowledgement $response)
            continue
        }
        Confirm-DirectController $response "$($remoteEndpoint.Address):$($remoteEndpoint.Port)" $remoteEndpoint.Address.ToString()
    }

    $now = Get-Date
    $referenceTime = if ($script:lastDirectAckAt -eq [DateTime]::MinValue) {
        $script:directStartedAt
    }
    else {
        $script:lastDirectAckAt
    }
    if ($now - $referenceTime -ge [TimeSpan]::FromSeconds(10) -and
        (-not $script:directStatusKnown -or $script:directConnected)) {
        Write-AgentStatus "direct controller unavailable: ${DirectHost}:$DirectPort"
        $script:directConnected = $false
        $script:directStatusKnown = $true
    }
}

function Get-ControllerCandidates([string]$Address) {
    $ip = $null
    if (-not [Net.IPAddress]::TryParse($Address, [ref]$ip) -or
        $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) { return }
    $octets = $ip.GetAddressBytes()
    $private = $octets[0] -eq 10 -or
        ($octets[0] -eq 172 -and $octets[1] -ge 16 -and $octets[1] -le 31) -or
        ($octets[0] -eq 192 -and $octets[1] -eq 168)
    if (-not $private) { return }
    # Search only the known controller's private /24, never the entire LAN.
    $prefix = "$($octets[0]).$($octets[1]).$($octets[2])"
    foreach ($suffix in 1..254) { if ($suffix -ne $octets[3]) { "$prefix.$suffix" } }
}

function Find-ControllerPage([string[]]$Addresses, [int]$HttpPort) {
    $requests = @()
    try {
        foreach ($address in $Addresses) {
            $request = [Net.HttpWebRequest]::Create("http://${address}:$HttpPort/")
            $request.Timeout = 1500
            $request.ReadWriteTimeout = 750
            $request.Proxy = $null
            $request.AllowAutoRedirect = $false
            $request.KeepAlive = $false
            $requests += @{ Host = $address; Request = $request; Pending = $request.BeginGetResponse($null, $null) }
        }
        # Send a real GET on the first connection; never hold an empty MCU socket.
        $deadline = [DateTime]::UtcNow.AddMilliseconds(1500)
        while ([DateTime]::UtcNow -lt $deadline -and
            @($requests | Where-Object { -not $_.Pending.IsCompleted }).Count -gt 0) {
            Start-Sleep -Milliseconds 10
        }
        foreach ($probe in $requests) {
            if (-not $probe.Pending.IsCompleted) { $probe.Request.Abort(); continue }
            try {
                $response = $probe.Request.EndGetResponse($probe.Pending)
                try {
                    $stream = $response.GetResponseStream()
                    $reader = [IO.StreamReader]::new($stream)
                    try {
                        $buffer = [char[]]::new(2048)
                        $count = 0
                        $readDeadline = [DateTime]::UtcNow.AddMilliseconds(750)
                        while ($count -lt $buffer.Length -and [DateTime]::UtcNow -lt $readDeadline) {
                            if ($stream.CanTimeout) {
                                $stream.ReadTimeout = [Math]::Max(1, [int]($readDeadline - [DateTime]::UtcNow).TotalMilliseconds)
                            }
                            $received = $reader.Read($buffer, $count, $buffer.Length - $count)
                            if ($received -eq 0) { break }
                            $count += $received
                            if ([string]::new($buffer, 0, $count) -match '<title>LED Forge Controller</title>') {
                                $probe.Host
                                break
                            }
                        }
                    }
                    finally { $reader.Dispose() }
                }
                finally { $response.Dispose() }
            }
            catch [Net.WebException] { }
            catch [IO.IOException] { }
        }
    }
    finally { foreach ($probe in $requests) { $probe.Request.Abort() } }
}

function Recover-DirectController {
    $now = Get-Date
    if ($null -ne $discoveryUdp) {
        $received = 0
        while ($discoveryUdp.Available -gt 0 -and $received -lt 8) {
            $received++
            $remote = [Net.IPEndPoint]::new([Net.IPAddress]::Any, 0)
            try { $packet = $discoveryUdp.Receive([ref]$remote) }
            catch [Net.Sockets.SocketException] { break }
            if ($directConnected) { continue }
            $hello = [Text.Encoding]::ASCII.GetString($packet)
            if ($hello -cnotmatch '\ALF1_HELLO,([0-9A-F]{6}),-?\d{1,3}\z') { continue }
            if (-not [string]::IsNullOrEmpty($controllerDeviceId) -and $Matches[1] -ne $controllerDeviceId) { continue }
            $candidate = $remote.Address.ToString()
            # HELLO alone never marks the account linked; require the normal ACK.
            $script:DirectHost = $candidate
            $script:nextDirectHttpAt = [DateTime]::MinValue
            Send-Heartbeat
            Read-DirectAcknowledgements
            if ($directConnected) { $script:discoveryCandidates = @(); return }
            $script:DirectHost = $confirmedDirectHost
        }
    }
    if ($directConnected -or $now -lt $nextDiscoveryAt -or
        $now - $directStartedAt -lt [TimeSpan]::FromSeconds(10)) { return }
    if ($discoveryCandidates.Count -eq 0) {
        $script:discoveryCandidates = @(Get-ControllerCandidates $DirectHost)
        # Include current private adapter /24s if the Wi-Fi network itself changed.
        foreach ($adapter in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
            if ($adapter.OperationalStatus -ne [Net.NetworkInformation.OperationalStatus]::Up -or
                $adapter.NetworkInterfaceType -eq [Net.NetworkInformation.NetworkInterfaceType]::Loopback) { continue }
            foreach ($address in $adapter.GetIPProperties().UnicastAddresses) {
                if ($address.Address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork) {
                    $script:discoveryCandidates += @(Get-ControllerCandidates $address.Address.ToString())
                }
            }
        }
        $script:discoveryCandidates = @($discoveryCandidates | Select-Object -Unique | Select-Object -First 1024)
        $script:discoveryIndex = 0
        if ($discoveryCandidates.Count -gt 0) {
            Write-AgentStatus "searching controller subnet near $DirectHost"
        }
    }
    if ($discoveryIndex -ge $discoveryCandidates.Count) {
        $script:discoveryCandidates = @()
        $script:nextDiscoveryAt = $now.AddSeconds(30)
        return
    }
    $end = [Math]::Min($discoveryIndex + 7, $discoveryCandidates.Count - 1)
    $candidates = @(Find-ControllerPage $discoveryCandidates[$discoveryIndex..$end] $DirectHttpPort)
    $script:discoveryIndex = $end + 1
    foreach ($candidate in $candidates) {
        Write-AgentStatus "controller candidate found: $candidate; verifying acknowledgement"
        $script:DirectHost = $candidate
        $script:nextDirectHttpAt = [DateTime]::MinValue
        Send-Heartbeat
        Read-DirectAcknowledgements
        if ($directConnected) { $script:discoveryCandidates = @(); break }
        $script:DirectHost = $confirmedDirectHost
    }
}

$mutex = [System.Threading.Mutex]::new($false, "Local\$InstanceName")
$ownsMutex = $false
try {
    try {
        $ownsMutex = $mutex.WaitOne(0)
    }
    catch [System.Threading.AbandonedMutexException] {
        # WaitOne grants ownership when the previous owning thread has exited.
        $ownsMutex = $true
    }
    if (-not $ownsMutex) {
        Write-AgentStatus 'Another agent owns this instance; exiting.'
        return
    }

    Write-AgentStatus 'Codex LAN activity agent started.'
    Write-AgentStatus "Client: $clientId"
    Write-AgentStatus "Optional LED Forge preview: ${CollectorHost}:$Port"
    Write-AgentStatus "Direct controller: ${DirectHost}:$DirectPort"
    Write-AgentStatus "Direct controller HTTP: http://${DirectHost}:$DirectHttpPort/agent"
    Write-AgentStatus "Agent name: $($metadata.Name); color: $($metadata.ColorHex6)"
    Write-AgentStatus 'Transmitting client identity, activity, remaining limit, and display metadata.'

    $tokenScanner = New-WeeklyTokenScanner
    if (-not $DisableLimitPolling) {
        $claudePoller = New-ClaudeQuotaPoller
        $claudeHttpSender = @{ Worker=$null; Pending=$null; Stopping=$null; Started=[DateTimeOffset]::MinValue }
    }

    while ($true) {
        if ($UpdateControlPath) {
            if (Test-Path -LiteralPath "$UpdateControlPath.stop") { break }
            [IO.File]::WriteAllText("$UpdateControlPath.health", [DateTime]::UtcNow.Ticks.ToString())
        }
        $now = Get-Date
        if ($null -ne $claudePoller) { Update-ClaudeQuotaPoller $claudePoller }
        Update-ClaudeHttpSender $claudeHttpSender
        try {
            $committedTokens = Receive-WeeklyTokenScan $tokenScanner
            if ($null -ne $committedTokens) {
                $weeklyTokens = $committedTokens
                $weeklyTokensReady = $true
                if ($null -ne $committedTokens.Daily) {
                    $dailyTokens = @($committedTokens.Daily)
                    $dailyTokenIdentity = $committedTokens.ReportIdentity
                    if ($dailyTokenIndex -ge $dailyTokens.Count) { $dailyTokenIndex = 0 }
                } else {
                    $dailyTokens = @(); $dailyTokenIdentity = ''
                }
                if ($committedTokens.DailyError) { Write-AgentStatus "Daily token checkpoint unavailable; retrying: $($committedTokens.DailyError)" }
            }
            if ($null -eq $tokenScanner.Pending -and $now -ge $nextTokenScan) {
                $nextTokenScan = $now.AddSeconds(15)
                [void](Start-WeeklyTokenScan $tokenScanner (Join-Path $PSScriptRoot 'weekly_tokens.ps1') $SessionsRoot $TokenStatePath -ReportIdentity (("$AccountFingerprint,$clientHash,$($metadata.ColorHex6),$($metadata.NameUtf8Hex)").ToUpperInvariant()))
            }
        }
        catch { Write-AgentStatus "Weekly token checkpoint unavailable; retrying: $($_.Exception.Message)" }
        if (-not $DisableLimitPolling -and $now -ge $nextLimitPoll) {
            $nextLimitPoll = $now.AddSeconds($LimitPollSeconds)
            $previousRemaining = $remainingPercent
            $latestRemaining = Get-RemainingPercent
            if ($null -ne $latestRemaining) {
                Update-AccountRemaining ([double]$latestRemaining)
                if ($remainingPercent -ne $previousRemaining) {
                    Write-AgentStatus "remaining limit: $remainingPercent%"
                }
            }
        }
        foreach ($file in Get-RecentSessionFiles) {
            try {
                Read-NewSessionContent $file
            }
            catch [System.IO.IOException] {
                # Codex may rotate a session while it is being inspected.
            }
        }

        $activity = Get-CurrentActivity
        Send-Heartbeat
        Read-DirectAcknowledgements
        Recover-DirectController
        if ($activity -ne $lastReportedActivity) {
            $state = if ($activity -gt 0) { "active ($activity)" } else { 'idle' }
            Write-AgentStatus $state
            $lastReportedActivity = $activity
        }
        Start-Sleep -Milliseconds $PollMilliseconds
    }
}
finally {
    Stop-LimitAppServer
    if ($null -ne $claudePoller) { Stop-ClaudeQuotaWorker $claudePoller }
    if ($null -ne $claudeHttpSender) { Stop-ClaudeQuotaWorker $claudeHttpSender }
    Stop-WeeklyTokenScanner $tokenScanner
    $udp.Dispose()
    if ($null -ne $discoveryUdp) { $discoveryUdp.Dispose() }
    try {
        if ($ownsMutex) { $mutex.ReleaseMutex() }
    }
    finally { $mutex.Dispose() }
}
