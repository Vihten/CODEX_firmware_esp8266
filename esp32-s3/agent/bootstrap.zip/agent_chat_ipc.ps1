﻿# Windows PowerShell 5.1. Dot-source agent_update.ps1 for durable file operations.
# Release-embedded agent_chat_peer.ps1
# Windows PowerShell 5.1. The release builder embeds this file at script scope.
function Initialize-ChatPeerWire {
    if ('CodexLan.PeerWireV1' -as [type]) { return }
    Add-Type -ReferencedAssemblies System.dll,System.Core.dll,System.Security.dll,System.Web.Extensions.dll -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

namespace CodexLan {
public sealed class PeerWireV1 : IDisposable {
    const string Version = "LFPEER1";
    const int MaxFrame = 2048, DeadlineMs = 4500, MaxPeers = 64;
    static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
    readonly object gate = new object();
    readonly X509Certificate2 cert;
    readonly string root, id, name;
    readonly IPAddress bind;
    readonly IPAddress discoveryAddress;
    readonly int discoveryPort;
    readonly HashSet<Guid> physical = new HashSet<Guid>();
    readonly TcpListener listener;
    readonly UdpClient udp;
    readonly Thread discovery;
    readonly Thread[] receivers = new Thread[4];
    readonly HashSet<TcpClient> active = new HashSet<TcpClient>();
    volatile bool stopped;
    public string Pin { get; private set; }
    public int TcpPort { get; private set; }
    public string LastReceiveError { get; private set; }

    public sealed class Row {
        public string id, name, pin, address;
        public bool online;
    }
    sealed class Location {
        public string Id, Name, Pin;
        public IPEndPoint Endpoint;
        public long Stamp;
        public readonly Stopwatch Age = Stopwatch.StartNew();
    }
    sealed class Binding {
        public string Name, Pin;
    }
    readonly Dictionary<string, Binding> trust = new Dictionary<string, Binding>();
    readonly Dictionary<string, Location> locations = new Dictionary<string, Location>();
    // Discovery-thread only. Charge attempts even if the socket send fails.
    readonly Stopwatch replyClock = Stopwatch.StartNew();
    readonly Dictionary<string,long> lastReply = new Dictionary<string,long>();
    readonly Queue<long> recentReplies = new Queue<long>();
    bool ReserveReply(string pin) {
        long now = replyClock.ElapsedMilliseconds;
        foreach (string key in lastReply.Where(x=>now-x.Value >= 8000).Select(x=>x.Key).ToArray())
            lastReply.Remove(key);
        while (recentReplies.Count != 0 && now-recentReplies.Peek() >= 1000) recentReplies.Dequeue();
        if (lastReply.ContainsKey(pin) || recentReplies.Count >= 16) return false;
        recentReplies.Enqueue(now);
        lastReply[pin] = now;
        return true;
    }

    static void Require(bool ok, string message) {
        if (!ok) throw new InvalidDataException(message);
    }
    static bool ValidId(string s) { return s != null && Regex.IsMatch(s, @"\A[0-9A-F]{8}\z"); }
    static bool ValidName(string s) {
        return !String.IsNullOrWhiteSpace(s) && s.Length <= 128 && !s.Any(Char.IsControl);
    }
    static void CheckMessage(string uuid, string body) {
        Guid parsed;
        Require(Guid.TryParseExact(uuid, "D", out parsed) && parsed.ToString("D") == uuid, "Invalid message ID");
        Require(!String.IsNullOrEmpty(body) && body.Length <= 512 && Utf8.GetByteCount(body) <= 512 &&
            !body.Any(c => c != '\n' && Char.IsControl(c)), "Invalid message text");
    }
    static string Fingerprint(X509Certificate c) {
        using (var sha = SHA256.Create())
            return BitConverter.ToString(sha.ComputeHash(c.GetRawCertData())).Replace("-", "");
    }
    static bool Current(X509Certificate2 c) {
        return c.NotBefore.ToUniversalTime() <= DateTime.UtcNow && c.NotAfter.ToUniversalTime() > DateTime.UtcNow;
    }
    static string B64(string s) { return Convert.ToBase64String(Utf8.GetBytes(s)); }
    static string Decode(string s) { return Utf8.GetString(Convert.FromBase64String(s)); }
    public PeerWireV1(string mailbox, string client, string displayName, X509Certificate2 certificate,
                      IPAddress local, IPAddress target, int discoveryPort, int tcpPort, string[] adapterIds) {
        Require(ValidId(client) && ValidName(displayName), "Invalid local identity");
        root = Path.GetFullPath(mailbox);
        foreach (var sub in new [] {"inbox","seen"}) {
            var dir = new DirectoryInfo(Path.Combine(root,sub));
            Require(dir.Exists, "Initialize private mailbox first");
            for (; dir != null; dir = dir.Parent)
                Require((dir.Attributes & FileAttributes.ReparsePoint) == 0, "Reparse mailbox rejected");
        }
        id = client; name = displayName; cert = certificate;
        Require(cert.HasPrivateKey && Current(cert), "Invalid local certificate");
        Pin = Fingerprint(cert);
        bind = local;
        discoveryAddress = target;
        this.discoveryPort = discoveryPort;
        foreach (string adapter in adapterIds) physical.Add(Guid.Parse(adapter));
        listener = new TcpListener(local,tcpPort);
        udp = new UdpClient(AddressFamily.InterNetwork);
        try {
            listener.ExclusiveAddressUse = true;
            listener.Start(8);
            TcpPort = ((IPEndPoint)listener.LocalEndpoint).Port;
            udp.ExclusiveAddressUse = true;
            udp.Client.Bind(new IPEndPoint(local,discoveryPort));
            udp.EnableBroadcast = true;
            discovery = new Thread(Discover) { IsBackground = true };
            for (int i=0; i<receivers.Length; i++) {
                receivers[i] = new Thread(Serve) { IsBackground = true };
                receivers[i].Start();
            }
            discovery.Start();
        } catch { Dispose(); throw; }
    }

    public void Trust(string peer, string displayName, string pin) {
        Require(ValidId(peer) && peer != id && ValidName(displayName) && pin != null &&
            Regex.IsMatch(pin, @"\A[0-9A-F]{64}\z") && pin != Pin, "Invalid peer binding");
        lock (gate) {
            Require(!stopped && (trust.ContainsKey(peer) || trust.Count < MaxPeers), "Trust table unavailable");
            Require(!trust.Any(x => x.Key != peer && x.Value.Pin == pin), "Pin already bound");
            trust[peer] = new Binding {Name=displayName, Pin=pin};
        }
    }
    public void Remove(string peer) { lock (gate) trust.Remove(peer); }
    bool Fresh(Location loc) { return loc.Age.ElapsedMilliseconds < 16000; }
    bool Bound(Location loc) {
        Binding b;
        return trust.TryGetValue(loc.Id,out b) && b.Pin == loc.Pin && b.Name == loc.Name;
    }
    Location Find(string peer, Binding b) {
        Location loc;
        return locations.TryGetValue(b.Pin, out loc) && loc.Id == peer && loc.Name == b.Name &&
            loc.Age.ElapsedMilliseconds < 40000 ? loc : null;
    }
    public Row[] Roster() {
        lock (gate) return trust.Select(x => new Row {id=x.Key, name=x.Value.Name, pin=x.Value.Pin, online=Find(x.Key,x.Value)!=null}).ToArray();
    }
    public Row[] Candidates() {
        lock (gate) return locations.Values.Where(Fresh).Where(x => !trust.ContainsKey(x.Id) && locations.Values.Count(y => y.Id == x.Id && Fresh(y)) == 1).Select(x => new Row {
            id=x.Id, name=x.Name, pin=x.Pin, address=x.Endpoint.Address.ToString(), online=true
        }).ToArray();
    }

    byte[] Beacon(bool reply = false) {
        // A leading '+' marks a terminal reply inside the signature. Legacy LFPEER1
        // readers parse the same positive Int64 and accept it as ordinary presence.
        string data = String.Join("|", Version, id, B64(name), TcpPort.ToString(),
            (reply ? "+" : "") + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString(),
            Convert.ToBase64String(cert.RawData));
        using (RSA key = cert.GetRSAPrivateKey()) {
            byte[] signature = key.SignData(Utf8.GetBytes(data),HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
            return Utf8.GetBytes(data + "|" + Convert.ToBase64String(signature));
        }
    }
    void AcceptBeacon(byte[] packet, int size, IPEndPoint source) {
        if (size > 4096) return;
        var data = Utf8.GetString(packet,0,size);
        var p = data.Split('|');
        int port; long stamp;
        if (p.Length != 7 || p[0] != Version || !ValidId(p[1]) || p[1] == id ||
            !Int32.TryParse(p[3],out port) || port < 1 || port > 65535 ||
            !Int64.TryParse(p[4],out stamp)) return;
        long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        if (stamp < now-15000 || stamp > now+15000) return;
        string displayName = Decode(p[2]);
        if (!ValidName(displayName)) return;
        var raw = Convert.FromBase64String(p[5]);
        if (X509Certificate2.GetCertContentType(raw) != X509ContentType.Cert) return;
        using (var remote = new X509Certificate2(raw)) {
            string pin = Fingerprint(remote);
            if (pin == Pin || !Current(remote)) return;
            bool terminal = p[4][0] == '+';
            lock (gate) {
                Location old;
                if (locations.TryGetValue(pin,out old) && stamp <= old.Stamp) return;
            }
            using (var key = remote.GetRSAPublicKey()) {
                if (key == null || key.KeySize != 2048 || !key.VerifyData(
                    Utf8.GetBytes(data.Substring(0,data.LastIndexOf('|'))),Convert.FromBase64String(p[6]),
                    HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1)) return;
            }
            bool reply;
            lock (gate) {
                Binding b;
                // Check the current bindings when committing discovery, including terminal replies.
                if (trust.Any(x=>x.Value.Pin == pin && x.Key != p[1])) return;
                if (trust.TryGetValue(p[1],out b) && (b.Pin != pin || b.Name != displayName)) return;
                foreach (var k in locations.Where(x=>!Fresh(x.Value) &&
                    (!Bound(x.Value) || x.Value.Age.ElapsedMilliseconds >= 300000)).Select(x=>x.Key).ToArray())
                    locations.Remove(k);
                if (!locations.ContainsKey(pin) && locations.Count >= MaxPeers) {
                    if (!trust.Values.Any(x=>x.Pin == pin)) return;
                    var victim = locations.Keys.FirstOrDefault(k=>!trust.Values.Any(x=>x.Pin == k));
                    if (victim == null) return;
                    locations.Remove(victim);
                }
                locations[pin] = new Location {Id=p[1],Name=displayName,Pin=pin,
                    Endpoint=new IPEndPoint(source.Address,port),Stamp=stamp};
                reply = !terminal && ReserveReply(pin);
            }
            if (reply) Announce(Beacon(true),source.Address);
        }
    }
    void Announce(byte[] packet, IPAddress replyTo = null) {
        if (discoveryAddress != null && (replyTo == null ||
            (IPAddress.IsLoopback(bind) && IPAddress.IsLoopback(replyTo) && !replyTo.Equals(bind)))) {
            udp.Send(packet,packet.Length,new IPEndPoint(replyTo ?? discoveryAddress,discoveryPort));
            return;
        }
        foreach (var adapter in NetworkInterface.GetAllNetworkInterfaces()) {
            Guid guid;
            if (adapter.OperationalStatus != OperationalStatus.Up || !Guid.TryParse(adapter.Id,out guid) ||
                !(physical.Contains(guid) || (discoveryAddress != null && !bind.Equals(IPAddress.Any)))) continue;
            foreach (var item in adapter.GetIPProperties().UnicastAddresses) {
                if (item.Address.AddressFamily != AddressFamily.InterNetwork || item.IPv4Mask == null ||
                    (!bind.Equals(IPAddress.Any) && !bind.Equals(item.Address))) continue;
                var ip = item.Address.GetAddressBytes();
                var mask = item.IPv4Mask.GetAddressBytes();
                bool lan = ip[0]==10 || (ip[0]==172 && ip[1]>=16 && ip[1]<=31) || (ip[0]==192 && ip[1]==168);
                if (!lan || mask[0]==0 || mask[3]>=254) continue;
                if (replyTo != null) {
                    var target = replyTo.GetAddressBytes();
                    bool sameSubnet = true, network = true, broadcast = true;
                    for (int i=0;i<4;i++) {
                        int host = target[i] & (255 ^ mask[i]);
                        sameSubnet &= ((target[i] ^ ip[i]) & mask[i]) == 0;
                        network &= host == 0;
                        broadcast &= host == (255 ^ mask[i]);
                    }
                    if (!sameSubnet || network || broadcast || replyTo.Equals(item.Address)) continue;
                }
                for (int i=0;i<4;i++) ip[i] |= (byte)~mask[i];
                try {
                    using (var outbound = new UdpClient(new IPEndPoint(item.Address,0))) {
                        outbound.EnableBroadcast = replyTo == null;
                        outbound.Send(packet,packet.Length,new IPEndPoint(replyTo ?? new IPAddress(ip),discoveryPort));
                        if (replyTo != null) return;
                    }
                } catch (SocketException) { }
            }
        }
    }
    void Discover() {
        var clock = Stopwatch.StartNew();
        long next = 0, nextDirect = 0;
        var buffer = new byte[4097];
        while (!stopped) {
            try {
                if (clock.ElapsedMilliseconds >= next) {
                    next = clock.ElapsedMilliseconds + 4000;
                    var packet = Beacon();
                    Announce(packet);
                    if (clock.ElapsedMilliseconds >= nextDirect) {
                        nextDirect = clock.ElapsedMilliseconds + 12000;
                        IPAddress[] targets;
                        lock (gate) targets = locations.Values.Where(x => Bound(x) &&
                            x.Age.ElapsedMilliseconds >= 8000 && x.Age.ElapsedMilliseconds < 300000)
                            .Select(x => x.Endpoint.Address).Distinct().ToArray();
                        foreach (var target in targets) Announce(packet,target);
                    }
                }
                if (!udp.Client.Poll(250000,SelectMode.SelectRead)) continue;
                EndPoint source = new IPEndPoint(IPAddress.Any,0);
                int n = udp.Client.ReceiveFrom(buffer,ref source);
                AcceptBeacon(buffer,n,(IPEndPoint)source);
            } catch (Exception) { if (stopped) break; }
            Thread.Sleep(15);
        }
    }
    static byte[] Exact(Stream stream, int n) {
        var data = new byte[n];
        for (int offset=0; offset<n;) {
            int read = stream.Read(data,offset,n-offset);
            if (read == 0) throw new EndOfStreamException();
            offset += read;
        }
        return data;
    }
    static string[] ReadFrame(Stream stream) {
        byte[] header = Exact(stream,2);
        int n = header[0]*256 + header[1];
        Require(n > 0 && n <= MaxFrame, "Invalid peer frame length");
        return Utf8.GetString(Exact(stream,n)).Split('|');
    }
    static void Frame(Stream stream, params string[] fields) {
        byte[] data = Utf8.GetBytes(String.Join("|",fields));
        Require(data.Length <= MaxFrame, "Oversized peer frame");
        stream.Write(new byte[]{(byte)(data.Length>>8),(byte)data.Length},0,2);
        stream.Write(data,0,data.Length);
        stream.Flush();
    }
    bool AcceptCert(X509Certificate candidate, string expected) {
        if (candidate == null) return false;
        using (var c = new X509Certificate2(candidate)) {
            string pin = Fingerprint(c);
            if (!Current(c) || pin == Pin) return false;
            lock (gate) return !stopped && trust.Any(x=>x.Value.Pin == pin && (expected == null || expected == x.Key));
        }
    }
    static void CheckTls(SslStream tls) {
        Require(tls.IsSigned && tls.IsEncrypted && tls.IsMutuallyAuthenticated && tls.RemoteCertificate != null,
                "Mutual TLS required");
    }
    string AssertBinding(string peer, string pin) {
        Binding b;
        Require(!stopped && peer != id && trust.TryGetValue(peer,out b) && trust[peer].Pin == pin,
                "Peer certificate binding rejected");
        return trust[peer].Name;
    }
    bool AlreadyDelivered(string path, string uuid, string sender, string pin, string body) {
        try {
            using (var f = new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete)) {
                Require(f.Length > 0 && f.Length <= 8192 &&
                    (File.GetAttributes(path) & FileAttributes.ReparsePoint) == 0, "Invalid receipt record");
                var json = Utf8.GetString(Exact(f,(int)f.Length)).TrimStart('\uFEFF');
                var record = new JavaScriptSerializer {MaxJsonLength=8192,RecursionLimit=4}
                    .Deserialize<Dictionary<string,object>>(json);
                Require((string)record["id"]==uuid && (string)record["sender_id"]==sender &&
                    record.ContainsKey("sender_fingerprint") && (string)record["sender_fingerprint"]==pin && (string)record["text"]==body, "Message ID conflict");
                return true;
            }
        } catch (FileNotFoundException) { return false; }
    }
    void Deliver(string uuid, string sender, string senderName, string pin, string body) {
        string inbox = Path.Combine(root,"inbox");
        string path = Path.Combine(inbox,uuid+".json");
        string seen = Path.Combine(root,"seen",uuid+".json");
        // The tray moves inbox to seen in this direction. Hold an open read handle across the move.
        if (AlreadyDelivered(path,uuid,sender,pin,body) || AlreadyDelivered(seen,uuid,sender,pin,body)) return;
        Require(Directory.EnumerateFiles(inbox,"*.json").Take(64).Count()<64,"Inbox full");
        byte[] data = Utf8.GetBytes(new JavaScriptSerializer().Serialize(new {
            id=uuid, sender_id=sender, sender_name=senderName, sender_fingerprint=pin, text=body
        }));
        string temp = Path.Combine(inbox,Guid.NewGuid().ToString("N")+".tmp");
        try {
            using (var f = new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {
                f.Write(data,0,data.Length);
                f.Flush(true);
            }
            File.Move(temp,path);
        } finally { File.Delete(temp); }
    }
    void Receive(TcpClient client) {
        using (var tls = new SslStream(client.GetStream(),false,
                (s,c,ch,e)=>AcceptCert(c,null))) {
            tls.AuthenticateAsServer(cert,true,SslProtocols.Tls12,false);
            CheckTls(tls);
            var p = ReadFrame(tls);
            Require(p.Length==7 && p[0]==Version && p[1]=="SEND" && ValidId(p[2]) && p[3]==id, "Invalid recipient or frame");
            var sender = p[2];
            var senderName = Decode(p[5]);
            var body = Decode(p[6]);
            CheckMessage(p[4],body);
            lock (gate) {
                string pin = Fingerprint(tls.RemoteCertificate);
                string trustedName = AssertBinding(sender,pin);
                Require(trustedName == senderName, "Sender name mismatch");
                Deliver(p[4],sender,trustedName,pin,body);
            }
            Frame(tls,Version,"ACK",id,sender,p[4]);
        }
    }
    static void Close(object obj) {
        try { ((TcpClient)obj).Close(); } catch (ObjectDisposedException) { }
    }
    void Serve() {
        while (!stopped) {
            try {
                using (var client = listener.AcceptTcpClient()) {
                    lock (gate) {
                        if (stopped) return;
                        active.Add(client);
                    }
                    try {
                        using (var deadline = new Timer(Close,client,DeadlineMs,Timeout.Infinite)) Receive(client);
                    } finally { lock (gate) active.Remove(client); }
                }
            } catch (Exception ex) {
                if (stopped) break;
                LastReceiveError = ex.GetType().Name + ": " + ex.Message;
            }
        }
    }
    public string Send(string recipient,string uuid,string body) {
        CheckMessage(uuid,body);
        Binding b;
        IPEndPoint endpoint;
        using (var client = new TcpClient(new IPEndPoint(bind,0))) {
            lock (gate) {
                Require(!stopped && recipient != id && trust.ContainsKey(recipient), "Untrusted recipient");
                b = trust[recipient];
                Location loc = Find(recipient,b);
                Require(loc != null,"Peer offline");
                endpoint = loc.Endpoint;
                active.Add(client);
            }
            try {
                using (var deadline = new Timer(Close,client,DeadlineMs,Timeout.Infinite)) {
                    client.Connect(endpoint);
                    using (var tls = new SslStream(client.GetStream(),false,
                        (s,c,ch,e)=>AcceptCert(c,recipient), (s,h,cs,r,issuers)=>cert)) {
                        tls.AuthenticateAsClient("codex-peer-"+recipient,new X509CertificateCollection {cert},SslProtocols.Tls12,false);
                        CheckTls(tls);
                        lock (gate) AssertBinding(recipient,Fingerprint(tls.RemoteCertificate));
                        Frame(tls,Version,"SEND",id,recipient,uuid,B64(name),B64(body));
                        var ack = ReadFrame(tls);
                        Require(ack.Length==5 && ack[0]==Version && ack[1]=="ACK" &&
                            ack[2]==recipient && ack[3]==id && ack[4]==uuid, "Invalid peer receipt");
                        return uuid;
                    }
                }
            } finally { lock (gate) active.Remove(client); }
        }
    }
    public void Dispose() {
        lock (gate) {
            if (stopped) return;
            stopped = true;
            foreach (var client in active) Close(client);
        }
        listener.Stop();
        udp.Close();
        foreach (Thread receiver in receivers) if (receiver != null && receiver.IsAlive) receiver.Join();
        if (discovery != null && discovery.IsAlive) discovery.Join();
    }
}
}
'@ -ErrorAction Stop
}

function Get-ChatPeerCertificate([string]$Client) {
    if ($Client -cnotmatch '\A[0-9A-F]{8}\z') { throw 'Invalid peer client ID' }
    Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Security/Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
    $subject = "CN=Codex-LAN-Peer-v1-$Client"
    $mutex = [Threading.Mutex]::new($false,"Local\CodexLanPeerCertificate-$Client")
    $held = $false
    try {
        try { $held = $mutex.WaitOne(10000) } catch [Threading.AbandonedMutexException] { $held = $true }
        if (-not $held) { throw 'Peer certificate initialization busy' }
        $found = @(Get-ChildItem Cert:\CurrentUser\My -ErrorAction Stop | Where-Object { $_.Subject -ceq $subject })
        if ($found.Count -gt 1) { throw 'Ambiguous local peer certificate' }
        if ($found.Count) { return $found[0] }
        Import-Module (Join-Path $PSHOME 'Modules/PKI/PKI.psd1') -ErrorAction Stop
        New-SelfSignedCertificate -Subject $subject -CertStoreLocation Cert:\CurrentUser\My -Type Custom -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -KeyUsage DigitalSignature,KeyEncipherment -TextExtension '2.5.29.37={text}1.3.6.1.5.5.7.3.1,1.3.6.1.5.5.7.3.2' -NotAfter ([datetime]::Now.AddYears(3)) -ErrorAction Stop
    } finally {
        if ($held) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Start-ChatPeerRuntime {
    param([string]$Root,[string]$Client,[string]$Name,[ipaddress]$BindAddress='0.0.0.0',
          [ipaddress]$DiscoveryAddress,[ValidateRange(1,65535)][int]$DiscoveryPort=4214,
          [ValidateRange(0,65535)][int]$TcpPort=4215)
    Initialize-ChatPeerWire
    $certificate = Get-ChatPeerCertificate $Client
    $adapterIds = @()
    if (-not $DiscoveryAddress) {
        Import-Module (Join-Path $PSHOME 'Modules/NetAdapter/NetAdapter.psd1') -ErrorAction Stop
        $adapterIds = @(Get-NetAdapter -Physical -ErrorAction Stop | ForEach-Object { [string]$_.InterfaceGuid })
    }
    [CodexLan.PeerWireV1]::new($Root,$Client,$Name,$certificate,$BindAddress,$DiscoveryAddress,$DiscoveryPort,$TcpPort,[string[]]$adapterIds)
}
function Stop-ChatPeerRuntime($Runtime) { if ($Runtime) { $Runtime.Dispose() } }
function Set-ChatPeerTrust($Runtime,$PeerId,$Name,$Pin) { $Runtime.Trust($PeerId,$Name,$Pin) }
function Remove-ChatPeerTrust($Runtime,$PeerId) { $Runtime.Remove($PeerId) }
function Get-ChatPeerRoster($Runtime) { $Runtime.Roster() }
function Get-ChatPeerCandidates($Runtime) { $Runtime.Candidates() }
function Send-ChatPeerMessage($Runtime,$RecipientId,$Id,$Text) { $Runtime.Send($RecipientId,$Id,$Text) }

$chatUtf8 = [Text.UTF8Encoding]::new($false, $true)
$chatUuid = '\A[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\z'

function Request-LocalAgentRestart {
    $name = $env:LED_FORGE_TRAY_RESTART
    if ($name -cnotmatch '\ALocal\\LEDForgeTrayRestart-[0-9a-f]{32}\z') { return $false }
    try {
        $event = [Threading.EventWaitHandle]::OpenExisting($name,[Security.AccessControl.EventWaitHandleRights]::Modify)
        try { return $event.Set() } finally { $event.Dispose() }
    } catch [Threading.WaitHandleCannotBeOpenedException] { return $false }
}

function Read-ChatObject([string]$Path) {
    Assert-AgentPlainPath $Path
    $stream = [IO.File]::Open($Path,'Open','Read',[IO.FileShare]'Read,Delete')
    try {
        if ($stream.Length -gt 16384) { throw 'Mailbox record too large' }
        $length = [int]$stream.Length
        $reader = [IO.BinaryReader]::new($stream)
        $bytes = $reader.ReadBytes($length)
        $chatUtf8.GetString($bytes).TrimStart([char]0xfeff) | ConvertFrom-Json -ErrorAction Stop
    } finally { $stream.Dispose() }
}

function Write-ChatObject($Path,$Value) {
    Write-AgentDurable $Path ($chatUtf8.GetBytes((ConvertTo-Json -InputObject $Value -Depth 5 -Compress)))
}

function Initialize-ChatMailbox($Root) {
    Assert-AgentPlainPath $Root
    [void][IO.Directory]::CreateDirectory($Root)
    $acl = [IO.Directory]::GetAccessControl($Root)
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
    if (-not $acl.GetOwner([Security.Principal.SecurityIdentifier]).Equals($sid)) { throw 'Foreign mailbox' }
    $acl.SetAccessRuleProtection($true,$false)
    foreach ($rule in @($acl.Access)) { [void]$acl.RemoveAccessRuleAll($rule) }
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
    [IO.Directory]::SetAccessControl($Root,$acl)
    foreach ($name in 'inbox','outbox','seen','attempts','failed','deliveries','board-attempts','trusted') {
        $path = Join-Path $Root $name
        Assert-AgentPlainPath $path
        [void][IO.Directory]::CreateDirectory($path)
    }
}

function Get-ChatEndpoint($Path) {
    $ep = Read-ChatObject $Path
    $ip = $null
    if ($ep.Device -cnotmatch '\A[0-9A-Fa-f]{6}\z' -or $ep.Account -cne '53197668' -or
        -not [Net.IPAddress]::TryParse([string]$ep.Host,[ref]$ip) -or $ip.AddressFamily -ne 'InterNetwork' -or
        $ip.ToString() -cne $ep.Host -or [string]$ep.HttpPort -notmatch '\A[0-9]{1,5}\z' -or
        [int]$ep.HttpPort -lt 1 -or [int]$ep.HttpPort -gt 65535) { throw 'Invalid controller endpoint' }
    @{ Base="http://$($ip.ToString()):$($ep.HttpPort)"; Device=$ep.Device.ToUpperInvariant() }
}

function Get-ChatSecret($Root,$Device,$Client,[switch]$Create) {
    if ($Device -cnotmatch '\A[0-9A-F]{6}\z' -or $Client -cnotmatch '\A[0-9A-F]{8}\z') { throw 'Invalid pairing identity' }
    Add-Type -AssemblyName System.Security
    $path = Join-Path $Root "chat-key-$Device-$Client.bin"
    Assert-AgentPlainPath $path
    $entropy = $chatUtf8.GetBytes("LFCHAT1/$Device/$Client")
    if (-not [IO.File]::Exists($path)) {
        if (-not $Create) { throw 'Pairing required' }
        $key = [byte[]]::new(32)
        $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($key) } finally { $rng.Dispose() }
        $blob = [Security.Cryptography.ProtectedData]::Protect($key,$entropy,'CurrentUser')
        Write-AgentDurable $path $blob
    }
    if ((Get-Item -LiteralPath $path).Length -gt 4096) { throw 'Invalid protected key' }
    $key = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$entropy,'CurrentUser')
    if ($key.Length -ne 32) { throw 'Invalid chat key' }
    return ,$key
}

function Get-ChatMac([byte[]]$Key,[string]$Value) {
    $h = [Security.Cryptography.HMACSHA256]::new($Key)
    try { [BitConverter]::ToString($h.ComputeHash($chatUtf8.GetBytes($Value))).Replace('-','').ToLowerInvariant() }
    finally { $h.Dispose() }
}

function Get-ChatSequence($Context) {
    if ($Context.Seq -ge $Context.SequenceLimit) {
        $path = Join-Path $Context.Root ("sequence-" + $Context.Device + "-" + $Context.Client + ".json")
        Assert-AgentPlainPath $path
        $last = if ([IO.File]::Exists($path)) { (Read-ChatObject $path).limit } else { 0L }
        if ([string]$last -cnotmatch '\A[0-9]{1,16}\z' -or [long]$last -gt 9007199254736895L) { throw 'Invalid sequence state' }
        $start = [Math]::Max([long]$last,[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
        $limit = $start + 4096L
        Write-ChatObject $path @{limit=$limit}
        $Context.Seq = $start
        $Context.SequenceLimit = $limit
    }
    $Context.Seq = 1L + $Context.Seq
    $Context.Seq
}

function Invoke-ChatRest($Context,[ValidateSet('state','send')]$Operation,
        [string]$Id='', [string]$To='', [string]$Body='') {
    if ($Context.Stop -and $Context.Stop.WaitOne(0)) { throw 'Chat session stopping' }
    $path = "/chat/$Operation"
    $request = [Net.HttpWebRequest]::Create($Context.Base + $path)
    $request.Proxy = $null
    $request.AllowAutoRedirect = $false
    $request.Method = 'POST'
    $request.Timeout = 2500
    $request.ReadWriteTimeout = 2000
    $request.MaximumResponseHeadersLength = 8
    $request.KeepAlive = $false
    $request.ContentType = 'text/plain; charset=utf-8'
    $bytes = $chatUtf8.GetBytes($Body)
    if ($bytes.Length -gt 512) { throw 'Oversize chat body' }
    $request.ContentLength = $bytes.Length
    if ($Operation -ne 'state') {
        $seq = Get-ChatSequence $Context
        $client = $Context.Client
        $boot = $Context.Boot
        $request.Headers['X-Chat-Client'] = $client
        $request.Headers['X-Chat-Seq'] = [string]$seq
        $request.Headers['X-Chat-Mac'] = Get-ChatMac $Context.Key ("LFCHAT1",$boot,$client,$seq,$path,$Id,$To,$Body -join [char]10)
        if ($Id) { $request.Headers['X-Chat-Id'] = $Id }
        if ($To) { $request.Headers['X-Chat-To'] = $To }
    }
    $timer = [Diagnostics.Stopwatch]::StartNew()
    try {
        if ($bytes.Length) {
            $s = $request.GetRequestStream()
            try { $s.Write($bytes,0,$bytes.Length) } finally { $s.Dispose() }
        }
        $response = $request.GetResponse()
        try {
            if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -gt 8192) { throw 'Invalid chat response' }
            $stream = $response.GetResponseStream()
            $memory = [IO.MemoryStream]::new()
            try {
                $buffer = [byte[]]::new(1024)
                while (($count = $stream.Read($buffer,0,$buffer.Length)) -gt 0) {
                    if ($timer.ElapsedMilliseconds -gt 4500 -or $memory.Length + $count -gt 8192) { throw 'Chat response limit' }
                    $memory.Write($buffer,0,$count)
                }
                $json = $chatUtf8.GetString($memory.ToArray())
            } finally { $memory.Dispose(); $stream.Dispose() }
            if ($Operation -ne 'state') {
                $mac = Get-ChatMac $Context.Key ("LFCHAT1-REPLY",$boot,$client,$seq,$json -join [char]10)
                $actual = $response.Headers['X-Chat-Reply']
                if ($actual -cnotmatch '\A[0-9a-f]{64}\z') { throw 'Unsigned chat response' }
                $diff = 0
                for ($i=0; $i -lt 64; $i++) { $diff = $diff -bor ([int]$actual[$i] -bxor [int]$mac[$i]) }
                if ($diff) { throw 'Invalid chat response signature' }
            }
            ConvertFrom-Json -InputObject $json -ErrorAction Stop
        } finally { $response.Dispose() }
    } catch [Net.WebException] {
        $errorResponse = $_.Exception.Response
        if ($errorResponse) {
            $failure = [InvalidOperationException]::new('Chat request rejected')
            $failure.Data['Status'] = [int]$errorResponse.StatusCode
            $errorResponse.Dispose()
            throw $failure
        }
        throw
    } finally { $request.Abort() }
}

function Test-ChatText($Value) {
    $Value -is [string] -and $Value.Length -gt 0 -and $Value -notmatch '[\x00-\x09\x0b-\x1f\x7f]' -and $chatUtf8.GetByteCount($Value) -le 512
}

function Sync-ChatTrust($Root,$Context) {
    $bindings = @{}
    foreach ($file in [IO.Directory]::EnumerateFiles((Join-Path $Root 'trusted'),'*.json')) {
        if ($bindings.Count -ge 64) { break }
        try {
            $id = [IO.Path]::GetFileNameWithoutExtension($file)
            $row = Read-ChatObject $file
            if ($id -cnotmatch '\A[0-9A-F]{8}\z' -or $id -ceq $Context.Client -or $row.id -cne $id -or
                $row.fingerprint -isnot [string] -or $row.fingerprint -cnotmatch '\A[0-9A-F]{64}\z' -or
                $row.name -isnot [string] -or [string]::IsNullOrWhiteSpace($row.name) -or
                $row.name -match '[\p{Cc}]' -or $row.name.Length -gt 128) { continue }
            $bindings[$id] = $row
        } catch { continue }
    }
    if (-not $Context.Applied) { $Context.Applied = @{} }
    foreach ($id in @($Context.Applied.Keys)) {
        $old = $Context.Applied[$id]
        $new = $bindings[$id]
        if (-not $new -or $old.fingerprint -cne $new.fingerprint -or $old.name -cne $new.name) {
            Remove-ChatPeerTrust $Context.Peer $id
            $Context.Applied.Remove($id)
        }
    }
    if ($Context.Peer) {
        foreach ($id in $bindings.Keys) {
            if (-not $Context.Applied.ContainsKey($id)) {
                $row = $bindings[$id]
                try { Set-ChatPeerTrust $Context.Peer $id $row.name $row.fingerprint } catch { continue }
                $Context.Applied[$id] = $row
            }
        }
    }
    $Context.Bindings = $bindings
}

function Publish-ChatRoster($Root,$Context,$EndpointPath) {
    $Context.Online = @{}
    $rows = @([ordered]@{id=$Context.Client;name=$Context.Name;online=$true})
    $candidates = @()
    if ($Context.Peer) {
        foreach ($peer in (Get-ChatPeerRoster $Context.Peer | Sort-Object id)) {
            $binding = $Context.Applied[$peer.id]
            if ($binding) {
                if ($peer.online) { $Context.Online[$peer.id] = $true }
                $rows += [ordered]@{id=$peer.id;name=$binding.name;online=[bool]$peer.online;trusted=$true;fingerprint=$binding.fingerprint}
            }
        }
        $candidates = @(foreach ($peer in (Get-ChatPeerCandidates $Context.Peer | Sort-Object id,pin,address)) {
            [ordered]@{id=$peer.id;name=$peer.name;fingerprint=$peer.pin;address=[string]$peer.address}
        })
    }
    # Board availability is a local hint. Credentials are opened only for an explicitly queued board send.
    $ep = $null
    try { $ep = Get-ChatEndpoint $EndpointPath } catch {}
    $Context.Endpoint = $ep
    $boardReady = $ep -and [IO.File]::Exists((Join-Path $Root "chat-key-$($ep.Device)-$($Context.Client).bin"))
    $rows += [ordered]@{id='board';name='Табло';online=[bool]$boardReady}
    $snapshot = [ordered]@{self_id=$Context.Client;self_fingerprint=$Context.Peer.Pin;agents=$rows;candidates=$candidates}
    $json = ConvertTo-Json -InputObject $snapshot -Depth 5 -Compress
    if ($json -cne $Context.LastSnapshot) {
        Write-AgentDurable (Join-Path $Root 'roster.json') ($chatUtf8.GetBytes($json))
        $Context.LastSnapshot = $json
    }
}

function Get-ChatBoardBoot($Root,$Context,$Target) {
    $ep = $Context.Endpoint
    if (-not $ep) { throw 'Board endpoint unavailable' }
    if ($Target.device -and $Target.device -cne $ep.Device) { throw 'Selected board unavailable' }
    if ($Context.Device -cne $ep.Device -or -not $Context.Key) {
        $Context.Key = Get-ChatSecret $Root $ep.Device $Context.Client
        $Context.Device = $ep.Device
        $Context.Seq = 0L
        $Context.SequenceLimit = 0L
    }
    $Context.Base = $ep.Base
    $state = Invoke-ChatRest $Context state
    if ($state.boot -isnot [string] -or $state.boot -cnotmatch '\A[0-9a-f]{16}\z') { throw 'Invalid board boot' }
    $Context.Boot = $state.boot
}

function Get-ChatDraftDigest($Message) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try {
        $value = ($Message.recipient_ids -join ',') + [char]10 + $Message.text
        [BitConverter]::ToString($hash.ComputeHash($chatUtf8.GetBytes($value)))
    } finally { $hash.Dispose() }
}

function New-ChatDelivery($Context,$Message,$Legacy) {
    $unique = @{}
    $targets = @(foreach ($id in $Message.recipient_ids) {
        if ($id -isnot [string] -or $id -cnotmatch '\A([0-9A-F]{8}|board)\z' -or $id -ceq $Context.Client -or $unique.ContainsKey($id)) {
            throw 'Invalid recipient'
        }
        $unique[$id] = $true
        $pin = if ($id -cne 'board' -and $Context.Bindings.ContainsKey($id)) { $Context.Bindings[$id].fingerprint }
        $device = if ($id -ceq 'board') { $Context.Endpoint.Device }
        $state = if ($Legacy) { 'uncertain' } elseif ($id -cne 'board' -and -not $pin) { 'failed' } else { 'pending' }
        [pscustomobject]@{id=$id;state=$state;started=0L;retry=0L;pin=$pin;device=$device;boot=$null}
    })
    [pscustomobject]@{id=$Message.id;digest=(Get-ChatDraftDigest $Message);queued=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds();targets=$targets}
}

function Send-ChatTarget($Root,$Context,$Message,$Record,$Target,$Journal,$Now) {
    if ($Target.state -cne 'pending' -or ($Context.Stop -and $Context.Stop.WaitOne(0))) { return }
    if ($Target.started -and ($Now -lt $Target.started -or $Now - $Target.started -ge 590)) {
        $Target.state = 'uncertain'
    } elseif (-not $Target.started -and ($Now -lt $Record.queued -or $Now - $Record.queued -ge 86400)) {
        $Target.state = 'failed'
    } elseif ($Now -lt $Target.retry) { return }
    else {
        $board = $Target.id -ceq 'board'
        if (-not $board -and $Context.Bindings[$Target.id].fingerprint -cne $Target.pin) {
            $Target.state = if ($Target.started) { 'uncertain' } else { 'failed' }
        } else {
            try {
                if ($board) {
                    Get-ChatBoardBoot $Root $Context $Target
                    if ($Target.boot -and $Target.boot -cne $Context.Boot) { $Target.state = 'uncertain' }
                    else { $Target.boot = $Context.Boot; $Target.device = $Context.Device }
                } elseif (-not $Context.Peer -or -not $Context.Online.ContainsKey($Target.id)) { return }
            } catch {
                $Target.retry = $Now + 10
                Write-ChatObject $Journal $Record
                return
            }
            if ($Target.state -ceq 'pending') {
                if (-not $Target.started) { $Target.started = $Now }
                $Target.retry = $Now + 10
                # Persist the exact UUID, board boot or peer pin before the first uncertain network write.
                Write-ChatObject $Journal $Record
                try {
                    if ($board) {
                        $reply = Invoke-ChatRest $Context send $Message.id 'board' $Message.text
                        if ($reply.ok -isnot [bool] -or -not $reply.ok) { throw 'Invalid board receipt' }
                    } else {
                        $receipt = Send-ChatPeerMessage $Context.Peer $Target.id $Message.id $Message.text
                        if ($receipt -isnot [string] -or $receipt -cne $Message.id) { throw 'Invalid peer receipt' }
                    }
                    $Target.state = 'delivered'
                } catch { return }
            }
        }
    }
    Write-ChatObject $Journal $Record
}

function Send-ChatBoardDraft($Root,$Context,$Message,$Record) {
    if ($Record.digest -cne (Get-ChatDraftDigest $Message)) { return }
    $board = $Record.targets | Where-Object id -ceq 'board'
    if ($board.state -cne 'pending') { return }
    $path = Join-Path $Root "board-attempts/$($Message.id).json"
    if ([IO.File]::Exists($path)) {
        $progress = Read-ChatObject $path
        if ($progress.id -cne $Record.id -or $progress.digest -cne $Record.digest) { return }
    } else {
        $progress = [pscustomobject]@{id=$Record.id;digest=$Record.digest;queued=$Record.queued;targets=@($board)}
    }
    Send-ChatTarget $Root $Context $Message $progress $progress.targets[0] $path ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
}

function Invoke-ChatBoardCycle($Root,$EndpointPath,$Context) {
    foreach ($file in [IO.Directory]::EnumerateFiles((Join-Path $Root 'outbox'),'*.json')) {
        if ($Context.Stop.WaitOne(0)) { return }
        try {
            $msg = Read-ChatObject $file
            if ($msg.id -cnotmatch $chatUuid -or $msg.id -cne [IO.Path]::GetFileNameWithoutExtension($file) -or
                $msg.recipient_ids -cnotcontains 'board') { continue }
            $record = Read-ChatObject (Join-Path $Root "deliveries/$($msg.id).json")
            $Context.Endpoint = $null
            try { $Context.Endpoint = Get-ChatEndpoint $EndpointPath } catch {}
            Send-ChatBoardDraft $Root $Context $msg $record
        } catch { continue }
    }
}

function Send-ChatOutbox($Root,$Context) {
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    foreach ($path in [IO.Directory]::EnumerateFiles((Join-Path $Root 'outbox'),'*.json')) {
        if ($Context.Stop -and $Context.Stop.WaitOne(0)) { return }
        $name = [IO.Path]::GetFileName($path)
        $id = [IO.Path]::GetFileNameWithoutExtension($path)
        $failed = Join-Path $Root "failed/$name"
        $journal = Join-Path $Root "deliveries/$name"
        try {
            $msg = Read-ChatObject $path
            if ($id -cnotmatch $chatUuid -or $msg.id -cne $id -or -not (Test-ChatText $msg.text) -or
                $msg.recipient_ids -isnot [array] -or $msg.recipient_ids.Count -lt 1 -or $msg.recipient_ids.Count -gt 13) { throw 'Invalid draft' }
            if ([IO.File]::Exists($journal)) {
                $record = Read-ChatObject $journal
                if ($record.id -cne $id -or $record.digest -cne (Get-ChatDraftDigest $msg) -or
                    $record.targets -isnot [array] -or ($record.targets.id -join ',') -cne ($msg.recipient_ids -join ',')) { throw 'Draft or journal changed' }
            } else {
                $legacy = [IO.File]::Exists((Join-Path $Root "attempts/$name"))
                $record = New-ChatDelivery $Context $msg $legacy
                Write-ChatObject $journal $record
            }
        } catch {
            if (-not [IO.File]::Exists($failed)) { [IO.File]::Move($path,$failed) }
            continue
        }
        foreach ($t in $record.targets | Where-Object id -cne 'board') {
            Send-ChatTarget $Root $Context $msg $record $t $journal $now
        }
        $board = $record.targets | Where-Object id -ceq 'board'
        if ($board.state -ceq 'pending') {
            if (-not $Context.SeparateBoard) { Send-ChatBoardDraft $Root $Context $msg $record }
            $progressPath = Join-Path $Root "board-attempts/$id.json"
            if ([IO.File]::Exists($progressPath)) {
                $progress = Read-ChatObject $progressPath
                if ($progress.id -ceq $id -and $progress.digest -ceq $record.digest -and
                    $progress.targets[0].state -cin @('delivered','uncertain','failed')) {
                    $board.state = $progress.targets[0].state
                    Write-ChatObject $journal $record
                }
            }
        }
        if ($record.targets.state -ccontains 'pending') { continue }
        if (@($record.targets | Where-Object state -cne 'delivered').Count) {
            if (-not [IO.File]::Exists($failed)) { [IO.File]::Move($path,$failed) }
        } else { [IO.File]::Delete($path) }
    }
}

function Invoke-ChatCycle($Root,$EndpointPath,$Context) {
    $Context.Root = $Root
    Sync-ChatTrust $Root $Context
    Publish-ChatRoster $Root $Context $EndpointPath
    Send-ChatOutbox $Root $Context
}
function Show-AgentChatPairing($Root,$EndpointPath) {
    Add-Type -AssemblyName System.Windows.Forms
    $ep = Get-ChatEndpoint $EndpointPath
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash($chatUtf8.GetBytes("$env:COMPUTERNAME-$env:USERNAME"))
        $client = [BitConverter]::ToString($hash,0,4).Replace('-','')
        $key = Get-ChatSecret $Root $ep.Device $client -Create
        $fingerprint = [BitConverter]::ToString($sha.ComputeHash($key),0,8)
        $hex = [BitConverter]::ToString($key).Replace('-','').ToLowerInvariant()
    } finally { $sha.Dispose() }
    $dialog = [Windows.Forms.Form]::new()
    try {
        $dialog.Text = 'Підключення табло'
        $dialog.Width = 595
        $dialog.Height = 220
        $dialog.StartPosition = 'CenterScreen'
        $label = [Windows.Forms.Label]::new()
        $label.SetBounds(14,12,550,66)
        $label.Text = "ПК $client   Контролер $($ep.Device)   $($ep.Base)" + [Environment]::NewLine +
            "Відбиток ключа: $fingerprint" + [Environment]::NewLine + 'Скопіюйте ключ у форму контролера та підтвердьте підключення.'
        $field = [Windows.Forms.TextBox]::new()
        $field.SetBounds(14,84,545,24)
        $field.ReadOnly = $true
        $field.Text = $hex
        $open = [Windows.Forms.Button]::new()
        $open.Text = 'Відкрити форму контролера'
        $open.SetBounds(14,122,255,32)
        $open.Add_Click({ Start-Process -FilePath ($ep.Base + '/chat/pair?client=' + $client) })
        $dialog.Controls.AddRange(@($label,$field,$open))
        [void]$dialog.ShowDialog()
    } finally { $dialog.Dispose() }
}

function Start-AgentChatSession($Directory,$EndpointPath,$Client,$Root,$Name=$env:COMPUTERNAME,[hashtable]$PeerOptions=@{}) {
    Initialize-ChatMailbox $Root
    $lockPath = Join-Path $Root 'worker.lock'
    Assert-AgentPlainPath $lockPath
    $lock = [IO.File]::Open($lockPath,'OpenOrCreate','ReadWrite','None')
    $session = @{ Lock=$lock; Stop=[Threading.ManualResetEvent]::new($false); Jobs=@() }
    try {
        Write-ChatObject (Join-Path $Root 'roster.json') @{self_id=$Client;agents=@()}
        foreach ($role in 'transport','board','tray') {
            $space = [RunspaceFactory]::CreateRunspace()
            $space.ApartmentState = if ($role -eq 'tray') { 'STA' } else { 'MTA' }
            $space.ThreadOptions = 'ReuseThread'
            $ps = [PowerShell]::Create()
            $job = @{ Role=$role; Shell=$ps; Space=$space; Task=$null }
            $session.Jobs += $job
            $space.Open()
            $ps.Runspace = $space
            [void]$ps.AddScript({
                param($role,$directory,$endpoint,$client,$root,$stop,$name,$peerOptions)
                $ErrorActionPreference = 'Stop'
                . (Join-Path $directory 'agent_update.ps1')
                . (Join-Path $directory 'agent_chat_ipc.ps1')
                if ($role -eq 'tray') {
                    & (Join-Path $directory 'agent_chat_ui.ps1') -MailboxRoot $root -ChatStopEvent $stop
                    return
                }
                $ctx = @{Client=$client; Name=$name; Seq=0L; Stop=$stop; Root=$root; SeparateBoard=$true}
                if ($role -eq 'board') {
                    while (-not $stop.WaitOne(0)) {
                        Invoke-ChatBoardCycle $root $endpoint $ctx
                        [void]$stop.WaitOne(1500)
                    }
                    return
                }
                $nextStart = [datetime]::MinValue
                try {
                    while (-not $stop.WaitOne(0)) {
                        if (-not $ctx.Peer -and [datetime]::UtcNow -ge $nextStart) {
                            $nextStart = [datetime]::UtcNow.AddSeconds(15)
                            try { $ctx.Peer = Start-ChatPeerRuntime -Root $root -Client $client -Name $name @peerOptions } catch {}
                        }
                        try { Invoke-ChatCycle $root $endpoint $ctx } catch {
                            if ($stop.WaitOne(1000)) { break }
                        }
                        [void]$stop.WaitOne(1500)
                    }
                } finally { if ($ctx.Peer) { Stop-ChatPeerRuntime $ctx.Peer } }
            }).AddArgument($role).AddArgument($Directory).AddArgument($EndpointPath).AddArgument($Client).AddArgument($Root).AddArgument($session.Stop).AddArgument($Name).AddArgument($PeerOptions)
            $job.Task = $ps.BeginInvoke()
        }
        $session
    } catch { Stop-AgentChatSession $session; throw }
}

function Stop-AgentChatSession($Session, [switch]$WorkerExiting) {
    if (-not $Session) { return }
    [void]$Session.Stop.Set()
    foreach ($job in $Session.Jobs) {
        if ($job.Task) {
            if (-not $job.Task.AsyncWaitHandle.WaitOne(6500)) {
                if ($WorkerExiting -and $job.Role -eq 'tray') {
                    # Stop/EndInvoke/Dispose can all wait for an unmanaged STA call.
                    # Keep the mailbox lock and shared event until the worker exits.
                    $Session.TrayStillRunning = $true
                    continue
                }
                $job.Shell.Stop()
            }
            try { [void]$job.Shell.EndInvoke($job.Task) } catch { $job.Failure = $_.Exception }
        }
        $job.Shell.Dispose()
        $job.Space.Dispose()
    }
    if (-not $Session.TrayStillRunning) {
        $Session.Stop.Dispose()
        $Session.Lock.Dispose()
    }
}
