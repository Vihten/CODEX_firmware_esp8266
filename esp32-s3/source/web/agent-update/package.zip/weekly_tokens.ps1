$script:WeeklyTokenMaximum = [long]9007199254740991
$script:WeeklyTokenRecordLimit = 262144
$script:KyivTimeZone = [TimeZoneInfo]::FindSystemTimeZoneById('FLE Standard Time')

function Get-TokenWeek([DateTimeOffset]$Timestamp) {
    $local = [TimeZoneInfo]::ConvertTime($Timestamp, $script:KyivTimeZone)
    $days = (([int]$local.DayOfWeek + 6) % 7)
    return $local.Date.AddDays(-$days).ToString('yyyyMMdd', [Globalization.CultureInfo]::InvariantCulture)
}

function New-WeeklyTokenState([string]$Week) {
    return @{ Version = 1; Week = $Week; Total = [long]0; Events = @{}; Files = @{} }
}

function Read-WeeklyTokenState([string]$Path, [string]$Week) {
    $state = New-WeeklyTokenState $Week
    if (-not (Test-Path -LiteralPath $Path)) { return $state }
    try {
        $saved = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($saved.Version -ne 1 -or $saved.Week -ne $Week) { return $state }
        $total = ConvertTo-TokenInteger $saved.Total
        if ($null -eq $total) { return $state }
        $state.Total = $total
        foreach ($entry in $saved.Events.PSObject.Properties) { $state.Events[$entry.Name] = $true }
        foreach ($entry in $saved.Files.PSObject.Properties) {
            $f = $entry.Value
            $state.Files[$entry.Name] = @{
                Offset = [long]$f.Offset; Remainder = [string]$f.Remainder
                Input = [long]$f.Input; Output = [long]$f.Output
                Skipping = [bool]$f.Skipping
            }
            if ($state.Files[$entry.Name].Remainder.Length -gt $script:WeeklyTokenRecordLimit) {
                $state.Files[$entry.Name].Remainder = ''
                $state.Files[$entry.Name].Skipping = $true
            }
        }
        return $state
    }
    catch { return (New-WeeklyTokenState $Week) }
}

function Save-WeeklyTokenState($State, [string]$Path) {
    $temporary = "$Path.$PID.tmp"
    try {
        $json = $State | ConvertTo-Json -Compress -Depth 8
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes($json)
        $stream = [IO.FileStream]::new($temporary, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) }
        finally { $stream.Dispose() }
        if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    }
    finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force } }
}

function ConvertTo-TokenInteger($Value) {
    if ($null -eq $Value -or $Value -is [bool]) { return $null }
    $text = [Convert]::ToString($Value, [Globalization.CultureInfo]::InvariantCulture)
    $number = [long]0
    if ($text -cnotmatch '\A[0-9]+\z' -or -not [long]::TryParse($text, [ref]$number) -or
        $number -gt $script:WeeklyTokenMaximum) { return $null }
    return $number
}

function Add-WeeklyTokenLine($State, $FileState, [string]$Line, [DateTimeOffset]$Now) {
    if ($Line -notmatch '"token_count"') { return }
    try { $event = $Line | ConvertFrom-Json } catch { return }
    if ($event.type -ne 'event_msg' -or $event.payload.type -ne 'token_count') { return }
    $usage = $event.payload.info.total_token_usage
    $inputTokens = ConvertTo-TokenInteger $usage.input_tokens
    $outputTokens = ConvertTo-TokenInteger $usage.output_tokens
    if ($null -eq $inputTokens -or $null -eq $outputTokens) { return }
    $timestamp = [DateTimeOffset]::MinValue
    if ([string]$event.timestamp -cnotmatch '(Z|[+-][0-9]{2}:[0-9]{2})\z' -or
        -not [DateTimeOffset]::TryParse([string]$event.timestamp, [Globalization.CultureInfo]::InvariantCulture,
            [Globalization.DateTimeStyles]::None, [ref]$timestamp)) { return }
    if ($timestamp -gt $Now) { $FileState.Deferred = $true; return }
    # Cumulative snapshots include cached input and reasoning within input/output.
    $delta = [Math]::Max([long]0, $inputTokens - $FileState.Input) +
        [Math]::Max([long]0, $outputTokens - $FileState.Output)
    $FileState.Input = [Math]::Max($FileState.Input, $inputTokens)
    $FileState.Output = [Math]::Max($FileState.Output, $outputTokens)
    if ($delta -le 0) { return }
    if ((Get-TokenWeek $timestamp) -ne $State.Week) { return }
    # Forks copy timestamped cumulative prefixes. Do not include the file path in this key.
    $key = '{0}:{1}:{2}' -f $timestamp.UtcDateTime.Ticks, $inputTokens, $outputTokens
    if ($State.Events.ContainsKey($key)) { return }
    $State.Events[$key] = $true
    $State.Total = [Math]::Min($script:WeeklyTokenMaximum, $State.Total + $delta)
}

function Update-WeeklyTokenState($State, [string]$SessionsRoot, [DateTimeOffset]$Now) {
    $week = Get-TokenWeek $Now
    if ($State.Week -ne $week) {
        $State.Week = $week; $State.Total = [long]0; $State.Events = @{}; $State.Files = @{}
    }
    $changed = $false
    foreach ($file in Get-ChildItem -LiteralPath $SessionsRoot -Filter '*.jsonl' -File -Recurse -ErrorAction Stop) {
        $path = $file.FullName
        if (-not $State.Files.ContainsKey($path) -or $file.Length -lt $State.Files[$path].Offset) {
            $State.Files[$path] = @{ Offset = [long]0; Remainder = ''; Input = [long]0; Output = [long]0 }
            $changed = $true
        }
        $checkpoint = $State.Files[$path]
        if ($file.Length -eq $checkpoint.Offset) { continue }
        $originalOffset = $checkpoint.Offset
        $originalRemainder = $checkpoint.Remainder
        $originalSkipping = [bool]$checkpoint.Skipping
        $checkpoint.Deferred = $false
        $stream = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read,
            [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
        try {
            [void]$stream.Seek($checkpoint.Offset, [IO.SeekOrigin]::Begin)
            $reader = [IO.StreamReader]::new($stream)
            try {
                $buffer = [char[]]::new(32768)
                while (($count = $reader.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    $chunk = [string]::new($buffer, 0, $count)
                    if ($checkpoint.Skipping) {
                        $newline = $chunk.IndexOf("`n")
                        if ($newline -lt 0) { continue }
                        $chunk = $chunk.Substring($newline + 1)
                        $checkpoint.Skipping = $false
                    }
                    $lines = ([string]$checkpoint.Remainder + $chunk) -split "`n"
                    $checkpoint.Remainder = $lines[-1]
                    for ($i = 0; $i -lt $lines.Count - 1; $i++) {
                        if ($lines[$i].Length -le $script:WeeklyTokenRecordLimit) {
                            Add-WeeklyTokenLine $State $checkpoint $lines[$i].TrimEnd("`r") $Now
                            if ($checkpoint.Deferred) { break }
                        }
                    }
                    if ($checkpoint.Deferred) { break }
                    if ($checkpoint.Remainder.Length -gt $script:WeeklyTokenRecordLimit) {
                        $checkpoint.Remainder = ''; $checkpoint.Skipping = $true
                    }
                }
                $checkpoint.Offset = $stream.Position
            }
            finally { $reader.Dispose() }
        }
        finally { $stream.Dispose() }
        # Finished historical logs need not end in a newline; incomplete JSON is ignored.
        if (-not $checkpoint.Deferred -and -not $checkpoint.Skipping -and $checkpoint.Remainder) {
            Add-WeeklyTokenLine $State $checkpoint $checkpoint.Remainder $Now
        }
        if ($checkpoint.Deferred) {
            # A scan-time cutoff may be older than a concurrent append. Replay rather
            # than consuming the final snapshot of a session that subsequently goes idle.
            $checkpoint.Offset = $originalOffset
            $checkpoint.Remainder = $originalRemainder
            $checkpoint.Skipping = $originalSkipping
        }
        $changed = $true
    }
    return $changed
}

function New-WeeklyTokenScanner {
    return @{ Worker = [PowerShell]::Create(); Pending = $null }
}

function Start-WeeklyTokenScan($Scanner, [string]$HelperPath, [string]$SessionsRoot, [string]$StatePath,
    [DateTimeOffset]$Now = [DateTimeOffset]::UtcNow) {
    if ($null -ne $Scanner.Pending) { return $false }
    $Scanner.Worker.Commands.Clear()
    $Scanner.Worker.Streams.Error.Clear()
    [void]$Scanner.Worker.AddScript({
        param($HelperPath, $SessionsRoot, $StatePath, $Now)
        $ErrorActionPreference = 'Stop'
        . $HelperPath
        $state = Read-WeeklyTokenState $StatePath (Get-TokenWeek $Now)
        [void](Update-WeeklyTokenState $state $SessionsRoot $Now)
        Save-WeeklyTokenState $state $StatePath
        # Only a fully scanned, durably committed snapshot crosses the runspace boundary.
        [pscustomobject]@{ Week = $state.Week; Total = $state.Total }
    }).AddArgument($HelperPath).AddArgument($SessionsRoot).AddArgument($StatePath).AddArgument($Now)
    $Scanner.Pending = $Scanner.Worker.BeginInvoke()
    return $true
}

function Receive-WeeklyTokenScan($Scanner) {
    if ($null -eq $Scanner.Pending -or -not $Scanner.Pending.IsCompleted) { return $null }
    try {
        $result = $Scanner.Worker.EndInvoke($Scanner.Pending)
        if ($Scanner.Worker.HadErrors -or $result.Count -ne 1) { throw 'Weekly token scan failed before commit.' }
        return $result[0]
    }
    finally { $Scanner.Pending = $null }
}

function Stop-WeeklyTokenScanner($Scanner) {
    if ($null -eq $Scanner) { return }
    try {
        if ($null -ne $Scanner.Pending) {
            $Scanner.Worker.Stop()
            try { [void]$Scanner.Worker.EndInvoke($Scanner.Pending) } catch { }
        }
    }
    finally { $Scanner.Pending = $null; $Scanner.Worker.Dispose() }
}

function New-WeeklyTokenPacket($State, [string]$Account, [string]$Client, [string]$Color, [string]$NameHex) {
    if ($Account -cnotmatch '\A[0-9A-Fa-f]{8}\z' -or $Client -cnotmatch '\A[0-9A-Fa-f]{8}\z' -or
        $State.Week -cnotmatch '\A[0-9]{8}\z' -or $Color -cnotmatch '\A[0-9A-Fa-f]{6}\z' -or
        $NameHex -cnotmatch '\A(?:[0-9A-Fa-f]{2}){0,48}\z') { throw 'Invalid weekly token packet fields.' }
    $total = ConvertTo-TokenInteger $State.Total
    if ($null -eq $total) { throw 'Invalid weekly token total.' }
    $packet = 'LFT1,{0},{1},{2},{3},{4},{5}' -f $Account.ToUpperInvariant(), $Client.ToUpperInvariant(),
        $State.Week, $total.ToString([Globalization.CultureInfo]::InvariantCulture), $Color.ToUpperInvariant(), $NameHex.ToUpperInvariant()
    if ([Text.Encoding]::ASCII.GetByteCount($packet) -ge 160) { throw 'Weekly token packet too large.' }
    return $packet
}
